<?php

//CONST TARO_ADMIN_DB_NAME = 'taro_admin';

define('MAIN_DOMAIN_NAME','http://localhost');
define('ADMIN_DB_NAME','testspace_admin');
define('SHOP_DB_PREFIX','shop_');
define('TAG_TABLE_PREFIX','tag_');

//DB Credentials
define('DB_USER_NAME','root');
define('DB_PASSWORD','passw0rd');
define('DB_HOST','localhost');
define('DB_DRIVER','mysql');
define('DB_PORT','');

//S3 Credentials
define('S3_KEY','xxxxxx');
define('S3_SECRET_PASS','xxxxxxxxxxxxx');
define ('S3_SHOP','xxxxxxxxxxx');