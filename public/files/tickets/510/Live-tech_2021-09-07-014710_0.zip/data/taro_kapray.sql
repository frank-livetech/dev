-- MySQL dump 10.13  Distrib 8.0.25, for Linux (x86_64)
--
-- Host: localhost    Database: taro_kapray
-- ------------------------------------------------------
-- Server version	8.0.25-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_addresses`
--

DROP TABLE IF EXISTS `customer_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_addresses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `unit_no` varchar(100) DEFAULT NULL,
  `street_addr` varchar(512) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postal_code` varchar(25) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `customer_addresses_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_addresses`
--

LOCK TABLES `customer_addresses` WRITE;
/*!40000 ALTER TABLE `customer_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_registration`
--

DROP TABLE IF EXISTS `customer_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_registration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL COMMENT 'User Email Address',
  `password` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `dob` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'User Date Of Birth',
  `reg_date` timestamp NULL DEFAULT NULL COMMENT 'Registration Time Stamp',
  `last_logedin` timestamp NULL DEFAULT NULL COMMENT 'Last Login Activity',
  `phone` varchar(20) DEFAULT NULL,
  `zipcode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_registration`
--

LOCK TABLES `customer_registration` WRITE;
/*!40000 ALTER TABLE `customer_registration` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_codes`
--

DROP TABLE IF EXISTS `discount_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_codes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `discount_type` varchar(15) DEFAULT NULL,
  `code` varchar(10) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `valid_from_date` timestamp NOT NULL,
  `valid_to_date` timestamp NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-enabled, 0-disabled',
  `prod_category` int NOT NULL DEFAULT '0',
  `discount_cat1` int NOT NULL DEFAULT '0',
  `discount_cat2` int NOT NULL DEFAULT '0',
  `discount_cat3` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_codes`
--

LOCK TABLES `discount_codes` WRITE;
/*!40000 ALTER TABLE `discount_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_codes_user`
--

DROP TABLE IF EXISTS `discount_codes_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_codes_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `coupon_id` int NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_codes_user`
--

LOCK TABLES `discount_codes_user` WRITE;
/*!40000 ALTER TABLE `discount_codes_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_codes_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_card`
--

DROP TABLE IF EXISTS `gift_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gift_card` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` double(12,2) DEFAULT NULL,
  `amount_used` double(12,2) DEFAULT NULL,
  `expiry_date` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `gift_card_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_card`
--

LOCK TABLES `gift_card` WRITE;
/*!40000 ALTER TABLE `gift_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `gift_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `shop_code` varchar(100) NOT NULL,
  `quantity` int DEFAULT NULL,
  `unit_price` double(20,8) DEFAULT NULL,
  `discount` double(20,8) DEFAULT NULL,
  `user_data` text,
  `shipping_status` varchar(100) DEFAULT NULL,
  `order_shipping_info_id` int DEFAULT NULL,
  `return_status` varchar(100) DEFAULT NULL,
  `return_desc` text,
  `return_date` timestamp NULL DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `discount_code` varchar(100) DEFAULT NULL,
  `discount_cmt` text,
  `is_super_shop` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items_log`
--

DROP TABLE IF EXISTS `order_items_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `order_item_id` int NOT NULL,
  `logged_by_user_id` int DEFAULT NULL,
  `order_status` varchar(100) DEFAULT NULL,
  `log_comments` text,
  `log_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `logged_by_user_id` (`logged_by_user_id`),
  CONSTRAINT `order_items_log_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_log_ibfk_2` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_log_ibfk_3` FOREIGN KEY (`logged_by_user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items_log`
--

LOCK TABLES `order_items_log` WRITE;
/*!40000 ALTER TABLE `order_items_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_log`
--

DROP TABLE IF EXISTS `order_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `logged_by_user_id` int DEFAULT NULL,
  `order_status` varchar(100) DEFAULT NULL,
  `log_comments` text,
  `log_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `logged_by_user_id` (`logged_by_user_id`),
  CONSTRAINT `order_log_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_log_ibfk_2` FOREIGN KEY (`logged_by_user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_log`
--

LOCK TABLES `order_log` WRITE;
/*!40000 ALTER TABLE `order_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_shipping_info`
--

DROP TABLE IF EXISTS `order_shipping_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_shipping_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `shipping_comp_id` int DEFAULT NULL,
  `shipping_option` varchar(150) DEFAULT NULL,
  `shipping_ref` varchar(150) DEFAULT NULL,
  `shipping_address` text,
  `shipping_cost` double(12,2) DEFAULT NULL,
  `shipping_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_shipping_info_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_shipping_info`
--

LOCK TABLES `order_shipping_info` WRITE;
/*!40000 ALTER TABLE `order_shipping_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_shipping_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_transaction`
--

DROP TABLE IF EXISTS `order_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_transaction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_ref` varchar(100) DEFAULT NULL,
  `transaction_status` enum('Completed','Pending','Processing','Declined','Reversed') DEFAULT NULL,
  `transaction_type` varchar(200) DEFAULT NULL,
  `transaction_amount` double(20,8) DEFAULT NULL,
  `comments` text,
  `trans_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`,`transaction_ref`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_transaction`
--

LOCK TABLES `order_transaction` WRITE;
/*!40000 ALTER TABLE `order_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_transaction_assoc`
--

DROP TABLE IF EXISTS `order_transaction_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_transaction_assoc` (
  `order_id` int NOT NULL,
  `transaction_id` int NOT NULL,
  UNIQUE KEY `order_id` (`order_id`,`transaction_id`),
  KEY `transaction_id` (`transaction_id`),
  CONSTRAINT `order_transaction_assoc_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_transaction_assoc_ibfk_2` FOREIGN KEY (`transaction_id`) REFERENCES `order_transaction` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_transaction_assoc`
--

LOCK TABLES `order_transaction_assoc` WRITE;
/*!40000 ALTER TABLE `order_transaction_assoc` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_transaction_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `sub_shop_code` varchar(100) DEFAULT NULL,
  `order_ref` varchar(36) DEFAULT NULL,
  `user_data` text,
  `order_status` varchar(100) DEFAULT NULL,
  `referrer` int DEFAULT NULL,
  `clean_referrer` int DEFAULT NULL,
  `dated` timestamp NOT NULL,
  `tax_amount` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_ref` (`order_ref`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `customer_registration` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_inventory`
--

DROP TABLE IF EXISTS `product_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_inventory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `product_id` int NOT NULL,
  `amount` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_inventory_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `shop_locations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_inventory_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Will Hold the Acumulated In Location Inventory';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_inventory`
--

LOCK TABLES `product_inventory` WRITE;
/*!40000 ALTER TABLE `product_inventory` DISABLE KEYS */;
INSERT INTO `product_inventory` VALUES (1,1,1,6,'2021-06-26 08:52:44');
/*!40000 ALTER TABLE `product_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_inventory_log`
--

DROP TABLE IF EXISTS `product_inventory_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_inventory_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `create_date` timestamp NULL DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `comments` varchar(1024) NOT NULL,
  `reference` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `location_id` (`location_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_inventory_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_inventory_log_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `shop_locations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_inventory_log_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_inventory_log`
--

LOCK TABLES `product_inventory_log` WRITE;
/*!40000 ALTER TABLE `product_inventory_log` DISABLE KEYS */;
INSERT INTO `product_inventory_log` VALUES (1,1,1,1,'2021-06-26 08:52:36',1,'',''),(2,1,1,1,'2021-06-26 08:52:44',5,'','');
/*!40000 ALTER TABLE `product_inventory_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_filters`
--

DROP TABLE IF EXISTS `shop_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_filters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filter_name` varchar(255) NOT NULL,
  `filter_link` varchar(255) NOT NULL,
  `display_index` int NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_filters`
--

LOCK TABLES `shop_filters` WRITE;
/*!40000 ALTER TABLE `shop_filters` DISABLE KEYS */;
INSERT INTO `shop_filters` VALUES (1,'Featured','4',1,'2021-06-23 07:19:27',NULL),(2,'New Arrivals','6',2,'2021-06-23 07:19:27',NULL),(3,'Best Sellers','4',3,'2021-06-23 07:19:27',NULL),(4,'Sports','10',4,'2021-06-23 07:19:27',NULL),(5,'Casual','12',5,'2021-06-23 07:19:27',NULL),(6,'Under $20','16',6,'2021-06-23 07:19:27',NULL),(7,'Half Rim','17',7,'2021-06-23 07:19:27',NULL);
/*!40000 ALTER TABLE `shop_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_filters_def`
--

DROP TABLE IF EXISTS `shop_filters_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_filters_def` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_filters_def`
--

LOCK TABLES `shop_filters_def` WRITE;
/*!40000 ALTER TABLE `shop_filters_def` DISABLE KEYS */;
INSERT INTO `shop_filters_def` VALUES (1,'Clothing','%7B%22catCode%22%3A%22frames%22%7D','2021-06-23 07:19:26',NULL),(2,'Sunglasses','%7B%22catCode%22%3A%22sunglasses%22%7D','2021-06-23 07:19:26',NULL),(3,'Reading Glasses','%7B%22catCode%22%3A%22reading_glass%22%7D','2021-06-23 07:19:26',NULL),(4,'Featured','%7B%22featured%22%3A%22yes%22%7D','2021-06-23 07:19:26',NULL),(5,'Best Sellers','%7B%22featured%22%3A%22yes%22%7D','2021-06-23 07:19:26',NULL),(6,'Latest','%7B%22latest%22%3A%2215+days%22%7D','2021-06-23 07:19:26',NULL),(7,'Men','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22demograghics%22%3A%22gender_men%22%7D%7D%7D','2021-06-23 07:19:26',NULL),(8,'Women','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22demograghics%22%3A%22gender_women%22%7D%7D%7D','2021-06-23 07:19:26',NULL),(9,'Ray Ban','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22brand%22%3A%22brand_ray_ban%22%7D%7D%7D','2021-06-23 07:19:26',NULL),(10,'Safety Glasses','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22mood%22%3A%22mood_sports%22%7D%7D%7D','2021-06-23 07:19:26',NULL),(11,'Formal','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22mood%22%3A%22mood_formal%22%7D%7D%7D','2021-06-23 07:19:26',NULL),(12,'Casual','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22mood%22%3A%22mood_casual%22%7D%7D%7D','2021-06-23 07:19:26',NULL),(13,'Rectangle','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22frame_shape%22%3A%22frame_shape_rectangle%22%7D%7D%7D','2021-06-23 07:19:26',NULL),(14,'Cat Eye','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22frame_shape%22%3A%22frame_shape_cat_eye%22%7D%7D%7D','2021-06-23 07:19:26',NULL),(15,'Aviator','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22frame_shape%22%3A%22frame_shape_aviator%22%7D%7D%7D','2021-06-23 07:19:26',NULL),(16,'Under $20','%7B%22price_max%22%3A%2220%22%7D','2021-06-23 07:19:26',NULL),(17,'Half Rim','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22frame_type%22%3A%22frame_type_half_rim%22%7D%7D%7D','2021-06-23 07:19:26',NULL);
/*!40000 ALTER TABLE `shop_filters_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_locations`
--

DROP TABLE IF EXISTS `shop_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_locations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(512) NOT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `address` varchar(512) DEFAULT NULL,
  `city` varchar(512) DEFAULT NULL,
  `state` varchar(512) DEFAULT NULL,
  `country` varchar(512) DEFAULT NULL,
  `zipcode` varchar(512) DEFAULT NULL,
  `status` enum('active','inactive','unregistered','suspended') NOT NULL,
  `lat` double(20,8) DEFAULT NULL,
  `lng` double(20,8) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_locations`
--

LOCK TABLES `shop_locations` WRITE;
/*!40000 ALTER TABLE `shop_locations` DISABLE KEYS */;
INSERT INTO `shop_locations` VALUES (1,'791dcbee2c','abcd','','','','','','CA','','active',NULL,NULL,'2021-06-25 10:00:55','2021-06-25 10:56:55');
/*!40000 ALTER TABLE `shop_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_product_images`
--

DROP TABLE IF EXISTS `shop_product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_product_images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image` text NOT NULL,
  `product_id` int NOT NULL,
  `image_type` enum('360','product') NOT NULL DEFAULT 'product',
  `shop_id` int NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `vtry` tinyint(1) NOT NULL COMMENT '0= No, 1=Yes',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `shop_product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_product_images`
--

LOCK TABLES `shop_product_images` WRITE;
/*!40000 ALTER TABLE `shop_product_images` DISABLE KEYS */;
INSERT INTO `shop_product_images` VALUES (2,'16247256329753.png',1,'product',145,0,0);
/*!40000 ALTER TABLE `shop_product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_products`
--

DROP TABLE IF EXISTS `shop_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_cat_code` varchar(100) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `title` varchar(512) NOT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `location` int NOT NULL DEFAULT '1' COMMENT 'Inventory Location ID',
  `abbr` varchar(10) DEFAULT NULL COMMENT 'Abbrivation',
  `base_price` double(12,2) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `visibility` tinyint(1) DEFAULT NULL,
  `discount` double(12,2) DEFAULT NULL,
  `product_desc` text,
  `is_feature` enum('no','yes') NOT NULL DEFAULT 'no' COMMENT 'no,yes',
  `cost` decimal(10,2) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `back_order` int NOT NULL DEFAULT '0',
  `secondry_attr` text,
  `modal_number` varchar(255) DEFAULT NULL,
  `product_img` varchar(255) DEFAULT NULL,
  `sort_index` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_products`
--

LOCK TABLES `shop_products` WRITE;
/*!40000 ALTER TABLE `shop_products` DISABLE KEYS */;
INSERT INTO `shop_products` VALUES (1,'kurta','1234','kurta','kurta',1,'en',NULL,NULL,'2021-06-26 07:41:53','2021-06-26 16:41:08',NULL,NULL,NULL,'yes',134.00,NULL,-1,'Product Type: Kurta\nTechnique: Solid Embroidered\nFabric: Organza\nStyle: Basic','1234',NULL,0,1);
/*!40000 ALTER TABLE `shop_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_settings`
--

DROP TABLE IF EXISTS `shop_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key_shop` varchar(255) DEFAULT NULL,
  `value_shop` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_settings`
--

LOCK TABLES `shop_settings` WRITE;
/*!40000 ALTER TABLE `shop_settings` DISABLE KEYS */;
INSERT INTO `shop_settings` VALUES (1,'pick_from_store','Inactive'),(2,'cash_on_delivery','Active'),(3,'paypal_setting','Inactive'),(4,'merchant_email',''),(5,'360','Inactive'),(6,'delivery_charges','250'),(7,'vtryon','Inactive'),(8,'main_theme','Formal'),(9,'sub_theme','12'),(10,'color_scheme','Pastel'),(11,'facebook_link','https://abcd'),(12,'twitter_link','https://abcdc'),(13,'instagram_link','https://abcd'),(14,'whatsapp_link','acbd'),(15,'youtube_link','https://abcd'),(16,'tax',NULL),(17,'shop_description','abcd'),(18,'contact_email','madihamufti@gmail.com');
/*!40000 ALTER TABLE `shop_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_slides_banners`
--

DROP TABLE IF EXISTS `shop_slides_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_slides_banners` (
  `id` int NOT NULL AUTO_INCREMENT,
  `t1` varchar(255) DEFAULT NULL,
  `t2` varchar(255) DEFAULT NULL,
  `t3` varchar(255) DEFAULT NULL,
  `t3_link` varchar(500) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `display_index` int DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_slides_banners`
--

LOCK TABLES `shop_slides_banners` WRITE;
/*!40000 ALTER TABLE `shop_slides_banners` DISABLE KEYS */;
INSERT INTO `shop_slides_banners` VALUES (1,'Frames','Collection','Show More','','slides/slide_1.png','slide',1,'2021-06-23 07:19:26',NULL),(2,'Protective Eyewear','Safety Glasses','Show More','10','slides/slide_2.png','slide',2,'2021-06-23 07:19:26',NULL),(3,'Extended Fit','Glasses','Show More','11','slides/slide_3.png','slide',3,'2021-06-23 07:19:26',NULL),(4,'Gaming','Eye Protectors','Show More','12','slides/slide_4.png','slide',4,'2021-06-23 07:19:26',NULL),(5,'Sunglasses','From totally trendy to classically cool','Show More','2','banners/banner1.png','banner',1,'2021-06-23 07:19:26',NULL),(6,'Latest','Glasses','Show More','6','banners/banner2.png','banner',2,'2021-06-23 07:19:26',NULL),(7,'Men','Glasses','Show More','7','banners/banner3.png','banner',3,'2021-06-23 07:19:26',NULL),(8,'Women','Glasses','Show More','8','banners/banner4.png','banner',4,'2021-06-23 07:19:27',NULL),(9,'Shades','Ray Ban Icons','Discover More','2','banners/banner5.png','banner',5,'2021-06-23 07:19:27',NULL),(10,'Timeless Look','The Aviator','Discover More','15','banners/banner6.png','banner',6,'2021-06-23 07:19:27',NULL),(11,'Universal Bridge','Fit Glasses','Show More','15','banners/banner7.png','banner',7,'2021-06-23 07:19:27',NULL),(12,'Special collection already available.',NULL,'Show More','1','banners/banner8.png','banner',8,'2021-06-23 07:19:27','2021-06-23 07:35:59'),(13,'Clearance','','Under $20','16','banners/banner9.png','banner',9,'2021-06-23 07:19:27',NULL);
/*!40000 ALTER TABLE `shop_slides_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_address`
--

DROP TABLE IF EXISTS `user_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_address` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `unit_no` varchar(100) DEFAULT NULL,
  `street_addr` varchar(512) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `county` varchar(100) DEFAULT NULL,
  `postal_code` varchar(25) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_address_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Manage User Shipping Address';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_address`
--

LOCK TABLES `user_address` WRITE;
/*!40000 ALTER TABLE `user_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_data`
--

DROP TABLE IF EXISTS `user_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `template_code` varchar(255) NOT NULL,
  `value` json NOT NULL,
  `label` varchar(255) NOT NULL,
  `creation_Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `user_data_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_data`
--

LOCK TABLES `user_data` WRITE;
/*!40000 ALTER TABLE `user_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_prescription`
--

DROP TABLE IF EXISTS `user_prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_prescription` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lenses_id` varchar(200) DEFAULT NULL,
  `lenses_label` varchar(200) DEFAULT NULL,
  `rx_image_file` varchar(200) DEFAULT NULL,
  `coating_id` varchar(200) DEFAULT NULL,
  `coating_label` varchar(200) DEFAULT NULL,
  `prescription_id` varchar(200) DEFAULT NULL,
  `pres_price` varchar(200) DEFAULT NULL,
  `pres_prices_array` varchar(1000) DEFAULT NULL,
  `presc_opt` varchar(200) DEFAULT NULL,
  `od_sph_ttl` varchar(200) DEFAULT NULL,
  `od_sph` varchar(200) DEFAULT NULL,
  `od_cyl_ttl` varchar(200) DEFAULT NULL,
  `od_cyl` varchar(200) DEFAULT NULL,
  `od_axis` varchar(200) DEFAULT NULL,
  `od_add_ttl` varchar(200) DEFAULT NULL,
  `od_add` varchar(200) DEFAULT NULL,
  `os_sph_ttl` varchar(200) DEFAULT NULL,
  `os_sph` varchar(200) DEFAULT NULL,
  `os_cyl_ttl` varchar(200) DEFAULT NULL,
  `os_cyl` varchar(200) DEFAULT NULL,
  `os_axis` varchar(200) DEFAULT NULL,
  `os_add_ttl` varchar(200) DEFAULT NULL,
  `os_add` varchar(200) DEFAULT NULL,
  `pd_single` varchar(200) DEFAULT NULL,
  `pd_right` varchar(200) DEFAULT NULL,
  `pd_left` varchar(200) DEFAULT NULL,
  `pdtype` varchar(200) DEFAULT NULL,
  `prism` varchar(15) DEFAULT NULL,
  `prism_right` varchar(50) DEFAULT NULL,
  `prism_left` varchar(50) DEFAULT NULL,
  `prism_right_direct` varchar(50) DEFAULT NULL,
  `prism_left_direct` varchar(50) DEFAULT NULL,
  `patient_name` varchar(200) DEFAULT NULL,
  `patient_id` int DEFAULT NULL,
  `hid_rx_type` varchar(200) DEFAULT NULL,
  `hid_rx_type_label` varchar(200) DEFAULT NULL,
  `hid_lens_type` varchar(200) DEFAULT NULL,
  `hid_lens_type_label` varchar(200) DEFAULT NULL,
  `lens_option` varchar(200) DEFAULT NULL,
  `lens_option_label` varchar(200) NOT NULL,
  `lens_coating` varchar(100) DEFAULT NULL,
  `lens_coating_label` varchar(100) DEFAULT NULL,
  `tint_opt_id` varchar(200) DEFAULT NULL,
  `tint_opt` varchar(200) DEFAULT NULL,
  `tint_solid_variant` varchar(200) DEFAULT NULL,
  `tint_color` varchar(200) DEFAULT NULL,
  `order_id` int NOT NULL,
  `sendlater` varchar(10) NOT NULL,
  `full_array` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_prescription`
--

LOCK TABLES `user_prescription` WRITE;
/*!40000 ALTER TABLE `user_prescription` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_prescription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_registration`
--

DROP TABLE IF EXISTS `user_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_registration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL COMMENT 'User Email Address',
  `password` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `dob` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'User Date Of Birth',
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Registration Time Stamp',
  `last_logedin` timestamp NULL DEFAULT NULL COMMENT 'Last Login Activity',
  `phone` varchar(20) DEFAULT NULL,
  `zipcode` varchar(20) DEFAULT NULL,
  `is_deactivated` varchar(20) NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_registration`
--

LOCK TABLES `user_registration` WRITE;
/*!40000 ALTER TABLE `user_registration` DISABLE KEYS */;
INSERT INTO `user_registration` VALUES (1,'madiha2nd@gmail.com','fb349a4522f6191ff1fc5fcabf5bbe76','Madiha','Mufti','2021-06-23 07:19:26','2021-06-23 07:19:26',NULL,'',NULL,'no');
/*!40000 ALTER TABLE `user_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `user_id` int NOT NULL,
  `role` varchar(100) NOT NULL COMMENT 'Defined in Code. Sales Person,Manager, Admin etc',
  UNIQUE KEY `user_id` (`user_id`,`role`),
  CONSTRAINT `user_role_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,'shop_admin');
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-08  4:07:08
