-- MySQL dump 10.13  Distrib 8.0.25, for Linux (x86_64)
--
-- Host: localhost    Database: taro_ainak
-- ------------------------------------------------------
-- Server version	8.0.25-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_addresses`
--

DROP TABLE IF EXISTS `customer_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_addresses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `unit_no` varchar(100) DEFAULT NULL,
  `street_addr` varchar(512) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postal_code` varchar(25) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `customer_addresses_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_addresses`
--

LOCK TABLES `customer_addresses` WRITE;
/*!40000 ALTER TABLE `customer_addresses` DISABLE KEYS */;
INSERT INTO `customer_addresses` VALUES (3,1,'Shipping','311','444 B-1 S-1','Calgary','Alberta','CA','44423','3452353462'),(4,2,'Home','313',' quarry green SE','CALGARY','AB','CA','T2C5E8','4039784229'),(5,1,'Asad',NULL,'444 B-1 S-12','Calgary','Alberta','CA','44423','33411212'),(6,3,'Home','','6936 Timber Creek Ct','Clarksville','Maryland','US','21029','240-755-0150'),(7,2,'shipping','313','313 Quarry Green','Calgary','Alberta','CA','12345','543653645645'),(8,4,'Home','320','520 58th Avn SW, 320','Calgary','Alberta','CA','T2V 0H6','4034722803');
/*!40000 ALTER TABLE `customer_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_registration`
--

DROP TABLE IF EXISTS `customer_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_registration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL COMMENT 'User Email Address',
  `password` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `dob` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'User Date Of Birth',
  `reg_date` timestamp NULL DEFAULT NULL COMMENT 'Registration Time Stamp',
  `last_logedin` timestamp NULL DEFAULT NULL COMMENT 'Last Login Activity',
  `phone` varchar(20) DEFAULT NULL,
  `zipcode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_registration`
--

LOCK TABLES `customer_registration` WRITE;
/*!40000 ALTER TABLE `customer_registration` DISABLE KEYS */;
INSERT INTO `customer_registration` VALUES (1,'customer@lh.com','81dc9bdb52d04dc20036dbd8313ed055','Customer','Ainak','2021-04-02 12:38:46',NULL,NULL,'124235145326',NULL),(2,'muftimuid@gmail.com','81dc9bdb52d04dc20036dbd8313ed055','MUID','MUFTI','2021-03-23 05:06:41',NULL,NULL,'',NULL),(3,'ngulzari@gmail.com','81dc9bdb52d04dc20036dbd8313ed055','Muhammad','Gulzari','2021-03-28 02:10:27',NULL,NULL,'',NULL),(4,'customer@email.com','81dc9bdb52d04dc20036dbd8313ed055','ARIF','MUHMOOD','2021-03-28 15:50:54',NULL,NULL,'',NULL),(5,'imranrwp@gmail.com','68a24878cc568766b735c62be5f306ed','Imran','Khan','2021-03-28 17:33:14',NULL,NULL,'',NULL);
/*!40000 ALTER TABLE `customer_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_codes`
--

DROP TABLE IF EXISTS `discount_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_codes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `discount_type` varchar(15) DEFAULT NULL,
  `code` varchar(10) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `valid_from_date` timestamp NOT NULL,
  `valid_to_date` timestamp NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-enabled, 0-disabled',
  `prod_category` int NOT NULL DEFAULT '0',
  `discount_cat1` int NOT NULL DEFAULT '0',
  `discount_cat2` int NOT NULL DEFAULT '0',
  `discount_cat3` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_codes`
--

LOCK TABLES `discount_codes` WRITE;
/*!40000 ALTER TABLE `discount_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discount_codes_user`
--

DROP TABLE IF EXISTS `discount_codes_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_codes_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `coupon_id` int NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discount_codes_user`
--

LOCK TABLES `discount_codes_user` WRITE;
/*!40000 ALTER TABLE `discount_codes_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_codes_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_card`
--

DROP TABLE IF EXISTS `gift_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gift_card` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` double(12,2) DEFAULT NULL,
  `amount_used` double(12,2) DEFAULT NULL,
  `expiry_date` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `gift_card_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_card`
--

LOCK TABLES `gift_card` WRITE;
/*!40000 ALTER TABLE `gift_card` DISABLE KEYS */;
INSERT INTO `gift_card` VALUES (1,2,'7RZ6NA2',10.00,NULL,'2021-03-28 00:00:00'),(2,3,'CF3M7I3',100.00,NULL,'2021-04-06 00:00:00'),(3,1,'LK1CS9',100.00,94.08,'2021-04-30 00:00:00');
/*!40000 ALTER TABLE `gift_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_detail`
--

DROP TABLE IF EXISTS `order_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `prescription_id` int NOT NULL COMMENT 'if 0 no prescription selected',
  `quantity` int NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `sub_total` decimal(10,2) NOT NULL,
  `lens_price` decimal(10,2) NOT NULL,
  `lens_ids` int DEFAULT NULL COMMENT 'Serialize array',
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_detail_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_detail`
--

LOCK TABLES `order_detail` WRITE;
/*!40000 ALTER TABLE `order_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `quantity` int DEFAULT NULL,
  `unit_price` double(20,8) DEFAULT NULL,
  `discount` double(20,8) DEFAULT NULL,
  `user_data` text,
  `shipping_status` varchar(100) DEFAULT NULL,
  `order_shipping_info_id` int DEFAULT NULL,
  `return_status` varchar(100) DEFAULT NULL,
  `return_desc` text,
  `return_date` timestamp NULL DEFAULT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Payment Pending',
  `discount_code` varchar(256) DEFAULT NULL,
  `discount_cmt` text,
  `product_code` varchar(100) NOT NULL,
  `shop_code` varchar(100) NOT NULL,
  `is_super_shop` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (1,1,1,32.95000000,1.00000000,'','Not Shipped',1,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(2,1,1,32.95000000,1.00000000,'','Not Shipped',1,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(3,2,1,32.95000000,1.00000000,'','Not Shipped',3,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(4,2,1,32.95000000,1.00000000,'','Not Shipped',3,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(5,2,1,32.95000000,1.00000000,'','Not Shipped',3,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823124','ainak',0),(6,3,1,32.95000000,1.00000000,'','Not Shipped',5,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(7,3,1,32.95000000,1.00000000,'','Not Shipped',5,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(8,4,1,32.95000000,1.00000000,'','Not Shipped',7,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(9,5,1,32.95000000,1.00000000,'','Not Shipped',9,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823124','ainak',0),(10,6,1,32.95000000,1.00000000,'','Not Shipped',11,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823122','ainak',0),(11,7,1,32.95000000,1.00000000,'','Not Shipped',13,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(12,8,1,32.95000000,1.00000000,'','Not Shipped',15,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(13,9,1,32.95000000,1.00000000,'','Not Shipped',17,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(14,9,1,32.95000000,1.00000000,'','Not Shipped',17,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(15,10,1,32.95000000,1.00000000,'','Not Shipped',19,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(16,10,1,32.95000000,1.00000000,'','Not Shipped',19,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(17,11,1,32.95000000,1.00000000,'','Not Shipped',21,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(18,12,1,32.95000000,1.00000000,'','Not Shipped',23,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(19,13,1,32.95000000,1.00000000,'','Not Shipped',25,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(20,13,1,32.95000000,1.00000000,'','Not Shipped',25,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(21,14,1,32.95000000,1.00000000,'','Not Shipped',27,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823122','ainak',0),(22,15,2,32.95000000,1.00000000,'','Not Shipped',28,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823125','ainak',0),(23,16,1,32.95000000,1.00000000,'','Not Shipped',29,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823112','ainak',0),(24,17,1,32.95000000,1.00000000,'[{\"id\":\"1\",\"label\":\"Asad\",\"template_code\":\"pres_data\",\"value\":\"{\\\"pd\\\": \\\"49\\\", \\\"od_add\\\": \\\"+0.50\\\", \\\"od_cyl\\\": \\\"-4.50\\\", \\\"od_sph\\\": \\\"-11.25\\\", \\\"os_add\\\": \\\"+3.00\\\", \\\"os_cyl\\\": \\\"-1.00\\\", \\\"os_sph\\\": \\\"-8.25\\\", \\\"od_axis\\\": \\\"178\\\", \\\"os_axis\\\": \\\"163\\\", \\\"pd_left\\\": \\\"\\\", \\\"pd_right\\\": \\\"\\\", \\\"left_prism\\\": \\\"\\\", \\\"right_prism\\\": \\\"\\\", \\\"left_prism_direction\\\": \\\"\\\", \\\"right_prism_direction\\\": \\\"\\\"}\",\"page\":\"Prescription\",\"checkout_proc_code\":\"eye_glass_checkout\"}]','Not Shipped',30,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823125','ainak',0),(25,18,1,32.95000000,1.00000000,'','Not Shipped',31,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(26,18,2,32.95000000,1.00000000,'','Not Shipped',31,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823124','ainak',0),(27,19,1,32.95000000,1.00000000,'','Not Shipped',32,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(28,20,1,32.95000000,1.00000000,'','Not Shipped',33,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(29,21,1,32.95000000,1.00000000,'','Not Shipped',34,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(30,22,1,32.95000000,1.00000000,'','Not Shipped',35,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(31,23,1,32.95000000,1.00000000,'','Not Shipped',37,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(32,23,1,32.95000000,1.00000000,'','Not Shipped',37,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(33,24,1,32.95000000,1.00000000,'','Not Shipped',38,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(34,24,1,32.95000000,1.00000000,'','Not Shipped',38,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(35,25,2,32.95000000,1.00000000,'','Not Shipped',39,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823125','ainak',0),(36,25,2,32.95000000,1.00000000,'','Not Shipped',39,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823124','ainak',0),(37,26,1,32.95000000,1.00000000,'','Not Shipped',41,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(38,27,1,32.95000000,1.00000000,'','Not Shipped',42,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(39,28,1,32.95000000,1.00000000,'','Not Shipped',43,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(40,29,1,32.95000000,1.00000000,'','Not Shipped',44,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(41,30,1,32.95000000,1.00000000,'','Not Shipped',45,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(42,31,1,6.95000000,1.00000000,'','Not Shipped',46,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-445111','ainak',0),(43,32,1,6.95000000,1.00000000,'','Not Shipped',47,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-445111','ainak',0),(44,33,1,6.95000000,1.00000000,'','Not Shipped',48,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-445111','ainak',0),(45,34,1,6.95000000,1.00000000,'','Not Shipped',49,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-445111','ainak',0),(46,35,1,6.95000000,1.00000000,'','Not Shipped',50,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-445111','ainak',0),(47,36,1,6.95000000,1.00000000,'','Not Shipped',51,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-445111','ainak',0),(48,37,1,6.95000000,1.00000000,'','Not Shipped',52,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-445111','ainak',0),(49,38,2,6.95000000,1.00000000,'','Not Shipped',53,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-445111','ainak',0),(50,38,2,32.95000000,1.00000000,'','Not Shipped',53,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(51,38,2,32.95000000,1.00000000,'','Not Shipped',53,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(52,38,2,32.95000000,1.00000000,'','Not Shipped',53,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(53,39,1,32.95000000,1.00000000,'','Not Shipped',54,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(54,39,1,32.95000000,1.00000000,'','Not Shipped',54,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(55,39,1,32.95000000,1.00000000,'','Not Shipped',54,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(56,40,1,32.95000000,1.00000000,'','Not Shipped',55,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(57,40,1,32.95000000,1.00000000,'','Not Shipped',55,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(58,40,1,32.95000000,1.00000000,'','Not Shipped',55,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(59,41,1,32.95000000,1.00000000,'','Not Shipped',56,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(60,41,1,32.95000000,1.00000000,'','Not Shipped',56,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(61,41,1,32.95000000,1.00000000,'','Not Shipped',56,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(62,42,1,32.95000000,1.00000000,'','Not Shipped',57,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(63,42,1,32.95000000,1.00000000,'','Not Shipped',57,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(64,42,1,32.95000000,1.00000000,'','Not Shipped',57,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(65,43,2,32.95000000,1.00000000,'','Not Shipped',58,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(66,43,2,32.95000000,1.00000000,'','Not Shipped',58,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(67,43,2,32.95000000,1.00000000,'','Not Shipped',58,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(68,44,1,6.95000000,1.00000000,'','Not Shipped',60,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-445111','ainak',0),(69,45,1,32.95000000,1.00000000,'','Not Shipped',61,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(70,46,1,32.95000000,1.00000000,'','Not Shipped',62,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(71,47,1,32.95000000,1.00000000,'','Not Shipped',63,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(72,48,1,32.95000000,1.00000000,'','Not Shipped',65,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823125','ainak',0),(73,49,1,32.95000000,1.00000000,'','Not Shipped',66,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823124','ainak',0),(74,50,1,32.95000000,1.00000000,'','Not Shipped',67,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(75,51,1,32.95000000,1.00000000,'','Not Shipped',68,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(76,52,1,32.95000000,1.00000000,'','Not Shipped',69,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(77,53,1,32.95000000,1.00000000,'','Not Shipped',70,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823124','ainak',0),(78,54,1,32.95000000,1.00000000,'','Not Shipped',72,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(79,55,1,32.95000000,1.00000000,'','Not Shipped',73,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(80,55,1,32.95000000,1.00000000,'','Not Shipped',73,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(81,56,1,32.95000000,1.00000000,'','Not Shipped',74,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(82,57,1,32.95000000,1.00000000,'','Not Shipped',75,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823112','ainak',0),(83,58,1,32.95000000,1.00000000,'','Not Shipped',76,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823112','ainak',0),(84,59,1,32.95000000,1.00000000,'','Not Shipped',77,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(85,59,1,32.95000000,1.00000000,'','Not Shipped',77,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(86,60,1,32.95000000,1.00000000,'','Not Shipped',78,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(87,61,1,32.95000000,1.00000000,'','Not Shipped',79,NULL,NULL,NULL,'Warehouse Processing',NULL,NULL,'pc-7823126','ainak',0),(88,62,1,32.95000000,1.00000000,'','Not Shipped',80,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(89,63,1,32.95000000,1.00000000,'','Not Shipped',81,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(90,64,1,32.95000000,1.00000000,'','Not Shipped',82,NULL,NULL,NULL,'Warehouse Ready',NULL,NULL,'pc-7823126','ainak',0),(91,65,1,32.95000000,1.00000000,'','Not Shipped',83,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(92,65,1,32.95000000,1.00000000,'','Not Shipped',83,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823124','ainak',0),(93,66,1,32.95000000,1.00000000,'','Not Shipped',84,NULL,NULL,NULL,'Ready for Shipment',NULL,NULL,'pc-7823126','ainak',0),(94,66,1,32.95000000,1.00000000,'','Not Shipped',84,NULL,NULL,NULL,'In Workshop Queue',NULL,NULL,'pc-7823125','ainak',0),(95,67,1,32.95000000,1.00000000,'','Not Shipped',85,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823125','ainak',0),(96,68,1,32.95000000,1.00000000,'','Not Shipped',86,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823125','ainak',0),(97,69,1,32.95000000,1.00000000,'','Not Shipped',87,NULL,NULL,NULL,'Rejected by Shop',NULL,NULL,'pc-7823126','ainak',0),(98,70,1,32.95000000,1.00000000,'','Not Shipped',88,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(99,71,1,32.95000000,1.00000000,'','Not Shipped',89,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(100,72,1,32.95000000,1.00000000,'','Not Shipped',90,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(101,73,1,32.95000000,1.00000000,'','Not Shipped',91,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(102,74,1,32.95000000,1.00000000,'','Not Shipped',92,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(103,75,1,32.95000000,1.00000000,'','Not Shipped',93,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823128','ainak',0),(104,75,1,32.95000000,1.00000000,'','Not Shipped',93,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823127','ainak',0),(105,75,1,32.95000000,1.00000000,'','Not Shipped',93,NULL,NULL,NULL,'Payment Pending',NULL,NULL,'pc-7823126','ainak',0),(106,77,1,32.95000000,1.00000000,'','Not Shipped',95,NULL,NULL,NULL,'Payment Pending','','','pc-7823127','ainak',0),(129,89,1,6.95000000,1.00000000,'','Not Shipped',107,NULL,NULL,NULL,'Payment Pending','','','pc-445111','ainak',0),(130,89,1,20.50000000,1.00000000,'','Not Shipped',107,NULL,NULL,NULL,'Payment Pending','','','TWDBRWPAs2015','arif',1),(131,90,1,6.95000000,1.00000000,'','Not Shipped',108,NULL,NULL,NULL,'Payment Pending','','','pc-445111','ainak',0),(132,90,1,20.50000000,1.00000000,'','Not Shipped',108,NULL,NULL,NULL,'Payment Pending','','','TWDBRWPAs2015','arif',1),(133,91,1,6.95000000,1.00000000,'','Not Shipped',109,NULL,NULL,NULL,'Payment Pending','','','pc-445111','ainak',0),(134,91,1,20.50000000,1.00000000,'','Not Shipped',109,NULL,NULL,NULL,'Payment Pending','','','TWDBRWPAs2015','arif',1);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items_log`
--

DROP TABLE IF EXISTS `order_items_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `order_item_id` int NOT NULL,
  `logged_by_user_id` int DEFAULT NULL,
  `order_status` varchar(100) DEFAULT NULL,
  `log_comments` text,
  `log_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `logged_by_user_id` (`logged_by_user_id`),
  CONSTRAINT `order_items_log_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_log_ibfk_2` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_log_ibfk_3` FOREIGN KEY (`logged_by_user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items_log`
--

LOCK TABLES `order_items_log` WRITE;
/*!40000 ALTER TABLE `order_items_log` DISABLE KEYS */;
INSERT INTO `order_items_log` VALUES (1,61,6,1,'Shipped','','2021-04-23 21:26:26'),(2,61,6,1,'comments','this is comment','2021-04-23 22:32:07'),(3,61,6,1,'comments','dansfn asknfkjdnf','2021-04-23 22:36:27'),(4,61,6,1,'Returned','','2021-04-23 22:41:49'),(5,61,6,1,'In Workshop Queue','','2021-04-23 22:41:55'),(6,61,6,1,'Warehouse Processing','','2021-04-23 22:42:01'),(7,64,6,1,'comments','','2021-04-23 23:27:25'),(8,64,6,1,'comments','nqwkdna sdaskjdn','2021-04-23 23:33:50'),(9,64,6,1,'comments','kasndk asnd','2021-04-23 23:33:54'),(10,64,6,1,'Warehouse Ready','','2021-04-23 23:34:01'),(11,64,6,3,'comments','kqwndas dkjasnd','2021-04-23 23:34:17'),(12,66,5,1,'comments','bjkhkjnkjn','2021-04-29 15:35:33'),(13,66,5,1,'In Workshop Queue','','2021-04-29 15:44:13'),(14,66,5,1,'In Workshop Queue','','2021-04-29 15:45:46'),(15,66,5,1,'In Workshop Processing','','2021-04-30 20:44:51'),(16,66,5,1,'Workshop Process Complete','','2021-04-30 20:45:16'),(17,66,5,1,'In Workshop Queue','','2021-04-30 20:47:01'),(18,66,6,1,'In Workshop Queue','','2021-04-30 20:47:06'),(19,66,6,1,'Payment Pending','','2021-04-30 20:50:55'),(20,69,6,1,'Rejected by Shop','','2021-05-02 20:07:41'),(21,66,6,1,'Ready for Shipment','','2021-05-02 20:09:22');
/*!40000 ALTER TABLE `order_items_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_log`
--

DROP TABLE IF EXISTS `order_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `logged_by_user_id` int DEFAULT NULL,
  `order_status` varchar(100) DEFAULT NULL,
  `log_comments` text,
  `log_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `logged_by_user_id` (`logged_by_user_id`),
  CONSTRAINT `order_log_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_log_ibfk_2` FOREIGN KEY (`logged_by_user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_log`
--

LOCK TABLES `order_log` WRITE;
/*!40000 ALTER TABLE `order_log` DISABLE KEYS */;
INSERT INTO `order_log` VALUES (1,1,NULL,'Order Created','','2021-03-20 19:57:47'),(2,2,NULL,'Order Created','','2021-03-22 05:36:24'),(3,3,NULL,'Order Created','','2021-03-22 18:37:41'),(4,4,NULL,'Order Created','','2021-03-22 18:50:20'),(5,5,NULL,'Order Created','','2021-03-22 18:54:53'),(6,6,NULL,'Order Created','','2021-03-23 19:24:48'),(7,7,NULL,'Order Created','','2021-03-25 15:53:08'),(8,8,NULL,'Order Created','','2021-03-25 16:16:39'),(9,9,NULL,'Order Created','','2021-03-25 16:38:10'),(10,10,NULL,'Order Created','','2021-03-25 16:41:56'),(11,11,NULL,'Order Created','','2021-03-25 16:49:43'),(12,12,NULL,'Order Created','','2021-03-25 16:53:29'),(13,13,NULL,'Order Created','','2021-03-25 19:10:04'),(14,1,NULL,'in_workshop','','2021-03-26 14:19:16'),(15,1,NULL,'In workshop','','2021-03-26 14:21:58'),(16,1,NULL,'In workshop','','2021-03-26 14:22:37'),(17,1,NULL,'Not processed','','2021-03-26 14:22:39'),(18,1,NULL,'Rejected','','2021-03-26 14:22:44'),(19,1,NULL,'Awaiting shipment','','2021-03-26 14:22:49'),(20,1,NULL,'Shipped','','2021-03-26 14:22:51'),(21,1,NULL,'Delivered','','2021-03-26 14:22:53'),(22,1,NULL,'In workshop','','2021-03-26 14:22:56'),(23,2,NULL,'Awaiting shipment','','2021-03-26 14:34:37'),(24,2,NULL,'Rejected','','2021-03-26 14:35:07'),(25,1,NULL,'Not processed','','2021-03-26 14:36:14'),(26,1,NULL,'In workshop','','2021-03-26 14:36:16'),(27,1,NULL,'In workshop','','2021-03-26 14:37:16'),(28,1,NULL,'Not processed','','2021-03-26 14:37:19'),(29,1,NULL,'Rejected','','2021-03-26 14:37:23'),(30,1,NULL,'In workshop','','2021-03-26 14:37:27'),(31,14,NULL,'Order Created','','2021-03-26 15:00:09'),(32,15,NULL,'Order Created','','2021-03-26 15:06:17'),(33,16,NULL,'Order Created','','2021-03-26 15:33:03'),(34,17,NULL,'Order Created','','2021-03-26 15:41:26'),(35,18,NULL,'Order Created','','2021-03-26 19:02:21'),(36,19,NULL,'Order Created','','2021-03-26 19:15:16'),(37,20,NULL,'Order Created','','2021-03-26 19:18:12'),(38,21,NULL,'Order Created','','2021-03-26 19:19:46'),(39,22,NULL,'Order Created','','2021-03-26 19:25:41'),(40,23,NULL,'Order Created','','2021-03-26 19:27:50'),(41,24,NULL,'Order Created','','2021-03-27 04:17:30'),(42,2,NULL,'Rejected','','2021-03-27 04:29:26'),(43,2,NULL,'Not processed','','2021-03-27 18:19:50'),(44,2,NULL,'Rejected','','2021-03-27 18:25:47'),(45,2,NULL,'Awaiting shipment','','2021-03-27 18:27:07'),(46,1,NULL,'Not processed','','2021-03-27 18:32:23'),(47,1,NULL,'Rejected','','2021-03-27 18:33:23'),(48,1,NULL,'In workshop','','2021-03-27 18:33:27'),(49,1,NULL,'Awaiting shipment','','2021-03-27 18:33:31'),(50,1,NULL,'Not processed','','2021-03-27 18:36:19'),(51,1,NULL,'In workshop','','2021-03-27 18:36:22'),(52,1,NULL,'Rejected','','2021-03-27 18:39:43'),(53,1,NULL,'Awaiting shipment','','2021-03-27 18:39:46'),(54,1,NULL,'Rejected','','2021-03-27 18:40:03'),(55,1,NULL,'In workshop','','2021-03-27 18:40:05'),(56,1,NULL,'Delivered','','2021-03-27 18:40:07'),(57,25,NULL,'Order Created','','2021-03-27 18:53:52'),(58,26,NULL,'Order Created','','2021-03-28 02:16:53'),(59,24,NULL,'In workshop','','2021-03-28 03:05:37'),(60,24,NULL,'Rejected','','2021-03-28 03:05:43'),(61,24,NULL,'In workshop','','2021-03-28 03:05:44'),(62,24,NULL,'Awaiting shipment','','2021-03-28 03:05:45'),(63,24,NULL,'Delivered','','2021-03-28 03:05:45'),(64,24,NULL,'In workshop','','2021-03-28 03:05:46'),(65,24,NULL,'Awaiting shipment','','2021-03-28 03:21:52'),(66,24,NULL,'In workshop','','2021-03-28 03:21:54'),(67,24,NULL,'Awaiting shipment','','2021-03-28 03:21:58'),(68,24,NULL,'In workshop','','2021-03-28 03:21:59'),(69,24,NULL,'Delivered','','2021-03-28 03:22:03'),(70,24,NULL,'In workshop','','2021-03-28 03:22:05'),(71,21,NULL,'Rejected','','2021-03-28 03:22:20'),(72,27,NULL,'Order Created','','2021-03-29 14:58:29'),(73,3,3,'comments','product comment','2021-03-29 19:58:20'),(74,3,3,'comments','next comment','2021-03-29 20:14:16'),(75,4,3,'comments','NEwlamsfa sjkfnlnsldfasd','2021-03-29 20:22:09'),(76,28,NULL,'Order Created','','2021-03-30 21:09:08'),(77,29,NULL,'Order Created','','2021-03-30 21:11:30'),(78,1,NULL,'In Workshop Queue','','2021-04-02 12:55:48'),(79,1,NULL,'Received','','2021-04-02 12:55:52'),(80,1,NULL,'Workshop Process Completed','','2021-04-02 13:19:27'),(89,1,1,'Workshop Process Complete','','2021-04-02 13:48:19'),(90,1,1,'Received','','2021-04-02 13:48:45'),(91,1,1,'In Workshop Queue','','2021-04-02 16:41:18'),(92,3,NULL,'In Workshop Queue','','2021-04-02 17:27:39'),(93,3,3,'In Workshop Processing','','2021-04-02 17:30:07'),(94,1,1,'Received','','2021-04-02 17:30:30'),(95,24,1,'comments','naskdn asdknajkfnqwnfkldnf','2021-04-02 18:04:54'),(96,24,1,'In Workshop Queue','','2021-04-02 18:05:07'),(97,24,1,'In Workshop Processing','','2021-04-02 18:05:51'),(98,24,1,'In Workshop Queue','','2021-04-02 18:09:48'),(99,2,1,'Ready for Shipment','','2021-04-03 10:55:56'),(100,30,NULL,'Order Created','','2021-04-08 18:06:07'),(101,31,NULL,'Order Created','','2021-04-08 18:07:47'),(102,32,NULL,'Order Created','','2021-04-08 18:28:18'),(103,33,NULL,'Order Created','','2021-04-08 18:31:14'),(104,34,NULL,'Order Created','','2021-04-08 18:32:44'),(105,35,NULL,'Order Created','','2021-04-08 19:15:31'),(106,36,NULL,'Order Created','','2021-04-08 19:16:14'),(107,37,NULL,'Order Created','','2021-04-08 19:25:16'),(108,38,NULL,'Order Created','','2021-04-08 19:27:56'),(109,39,NULL,'Order Created','','2021-04-08 19:36:29'),(110,40,NULL,'Order Created','','2021-04-08 19:38:16'),(111,41,NULL,'Order Created','','2021-04-08 19:42:07'),(112,42,NULL,'Order Created','','2021-04-08 19:43:14'),(113,43,NULL,'Order Created','','2021-04-08 20:37:05'),(114,44,NULL,'Order Created','','2021-04-09 15:57:01'),(115,45,NULL,'Order Created','','2021-04-09 18:09:54'),(116,46,NULL,'Order Created','','2021-04-09 18:11:41'),(117,47,NULL,'Order Created','','2021-04-09 18:13:46'),(118,48,NULL,'Order Created','','2021-04-09 18:17:18'),(119,49,NULL,'Order Created','','2021-04-09 18:18:37'),(120,50,NULL,'Order Created','','2021-04-09 19:25:39'),(121,51,NULL,'Order Created','','2021-04-09 20:09:31'),(122,52,NULL,'Order Created','','2021-04-09 20:11:34'),(123,52,1,'comments','kjasnd dnaskdn','2021-04-10 14:11:26'),(124,52,1,'comments','kjasndsd vkjans','2021-04-10 14:11:33'),(125,52,1,'comments','asdasdasd asd','2021-04-10 14:11:40'),(126,53,NULL,'Order Created','','2021-04-10 17:49:32'),(127,54,NULL,'Order Created','','2021-04-16 11:27:32'),(128,55,NULL,'Order Created','','2021-04-16 11:35:03'),(129,56,NULL,'Order Created','','2021-04-16 11:40:15'),(130,57,NULL,'Order Created','','2021-04-17 18:08:57'),(131,58,NULL,'Order Created','','2021-04-17 18:09:09'),(132,58,1,'comments','test 123','2021-04-17 18:12:48'),(133,58,1,'comments','abc','2021-04-17 18:12:58'),(134,58,4,'Workshop Process Complete','','2021-04-17 18:43:25'),(135,59,NULL,'Order Created','','2021-04-17 19:14:04'),(136,60,NULL,'Order Created','','2021-04-17 21:44:53'),(137,61,NULL,'Order Created','','2021-04-22 20:00:59'),(138,62,NULL,'Order Created','','2021-04-22 20:12:09'),(139,63,NULL,'Order Created','','2021-04-22 20:22:07'),(140,58,1,'Payment Pending','','2021-04-22 20:51:48'),(141,24,1,'Payment Pending','','2021-04-22 20:53:08'),(142,64,NULL,'Order Created','','2021-04-23 20:59:19'),(143,61,1,'comments','this is comment','2021-04-23 21:11:02'),(144,61,1,'comments','this is 2nd comment','2021-04-23 21:18:55'),(145,61,1,'comments','this is latest comment','2021-04-23 21:19:01'),(146,65,NULL,'Order Created','','2021-04-25 16:51:57'),(147,66,NULL,'Order Created','','2021-04-29 15:34:53'),(148,67,NULL,'Order Created','','2021-04-29 23:50:11'),(149,68,NULL,'Order Created','','2021-04-29 23:50:20'),(150,69,NULL,'Order Created','','2021-04-29 23:51:02'),(151,70,NULL,'Order Created','','2021-05-03 12:04:20'),(152,71,NULL,'Order Created','','2021-05-03 12:29:23'),(153,72,NULL,'Order Created','','2021-06-09 18:27:14'),(154,73,NULL,'Order Created','','2021-06-09 18:29:56'),(155,74,NULL,'Order Created','','2021-06-09 23:50:20'),(156,75,NULL,'Order Created','','2021-06-09 23:53:46'),(157,76,NULL,'Order Created','','2021-06-11 04:28:28'),(158,77,NULL,'Order Created','','2021-06-11 04:35:29'),(170,89,NULL,'Order Created','','2021-06-20 00:34:29'),(171,90,NULL,'Order Created','','2021-06-20 00:37:43'),(172,91,NULL,'Order Created','','2021-06-20 00:38:29');
/*!40000 ALTER TABLE `order_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_shipping_info`
--

DROP TABLE IF EXISTS `order_shipping_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_shipping_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `shipping_comp_id` int DEFAULT NULL,
  `shipping_option` varchar(150) DEFAULT NULL,
  `shipping_ref` varchar(150) DEFAULT NULL,
  `shipping_address` text,
  `shipping_cost` double(12,2) DEFAULT NULL,
  `shipping_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_shipping_info_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_shipping_info`
--

LOCK TABLES `order_shipping_info` WRITE;
/*!40000 ALTER TABLE `order_shipping_info` DISABLE KEYS */;
INSERT INTO `order_shipping_info` VALUES (1,1,NULL,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(2,1,NULL,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(3,2,NULL,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(4,2,NULL,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(5,3,NULL,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(6,3,NULL,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(7,4,NULL,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',5.00,NULL),(8,4,NULL,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',5.00,NULL),(9,5,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',5.00,NULL),(10,5,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',5.00,NULL),(11,6,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',5.00,NULL),(12,6,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',5.00,NULL),(13,7,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',5.00,NULL),(14,7,2,'Mail Delivery',NULL,' 444 B-1 S-12, Calgary, Alberta 44423, Canada',5.00,NULL),(15,8,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(16,8,1,'Mail Delivery',NULL,' 444 B-1 S-12, Calgary, Alberta 44423, Canada',2.00,NULL),(17,9,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(18,9,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(19,10,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(20,10,1,'Mail Delivery',NULL,' 444 B-1 S-12, Calgary, Alberta 44423, Canada',2.00,NULL),(21,11,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(22,11,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(23,12,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(24,12,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(25,13,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',5.00,NULL),(26,13,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',5.00,NULL),(27,14,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(28,15,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(29,16,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(30,17,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(31,18,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',5.00,NULL),(32,19,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(33,20,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(34,21,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(35,22,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',2.00,NULL),(36,22,1,'Mail Delivery',NULL,' 444 B-1 S-12, Calgary, Alberta 44423, Canada',2.00,NULL),(37,23,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',5.00,NULL),(38,24,2,'Mail Delivery',NULL,'313  quarry green SE, CALGARY, AB T2C5E8, Canada',5.00,NULL),(39,25,5,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',1.00,NULL),(40,25,5,'Mail Delivery',NULL,' 444 B-1 S-12, Calgary, Alberta 44423, Canada',1.00,NULL),(41,26,5,'Mail Delivery',NULL,' 6936 Timber Creek Ct, Clarksville, Maryland 21029, United States of America',1.00,NULL),(42,27,5,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',1.00,NULL),(43,28,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(44,29,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(45,30,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(46,31,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(47,32,5,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',1.00,NULL),(48,33,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(49,34,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(50,35,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(51,36,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(52,37,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(53,38,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(54,39,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(55,40,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(56,41,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(57,42,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(58,43,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(59,43,2,'Mail Delivery',NULL,' 444 B-1 S-12, Calgary, Alberta 44423, Canada',15.00,NULL),(60,44,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(61,45,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(62,46,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(63,47,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(64,47,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(65,48,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(66,49,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(67,50,5,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',1.00,NULL),(68,51,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(69,52,5,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',1.00,NULL),(70,53,5,'Mail Delivery',NULL,'313  quarry green SE, CALGARY, AB T2C5E8, Canada',1.00,NULL),(71,53,5,'Mail Delivery',NULL,'313 313 Quarry Green, Calgary, Alberta 12345, Canada',1.00,NULL),(72,54,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(73,55,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(74,56,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(75,57,5,'Mail Delivery',NULL,'313  quarry green SE, CALGARY, AB T2C5E8, Canada',1.00,NULL),(76,58,5,'Mail Delivery',NULL,'313  quarry green SE, CALGARY, AB T2C5E8, Canada',1.00,NULL),(77,59,5,'Mail Delivery',NULL,'313  quarry green SE, CALGARY, AB T2C5E8, Canada',1.00,NULL),(78,60,5,'Mail Delivery',NULL,'313  quarry green SE, CALGARY, AB T2C5E8, Canada',1.00,NULL),(79,61,5,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',1.00,NULL),(80,62,5,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',1.00,NULL),(81,63,5,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',1.00,NULL),(82,64,5,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',1.00,NULL),(83,65,5,'Mail Delivery',NULL,'320 520 58th Avn SW, 320, Calgary, Alberta T2V 0H6, Canada',1.00,NULL),(84,66,5,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',1.00,NULL),(85,67,5,'Mail Delivery',NULL,'313  quarry green SE, CALGARY, AB T2C5E8, Canada',1.00,NULL),(86,68,5,'Mail Delivery',NULL,'313  quarry green SE, CALGARY, AB T2C5E8, Canada',1.00,NULL),(87,69,5,'Mail Delivery',NULL,'313  quarry green SE, CALGARY, AB T2C5E8, Canada',1.00,NULL),(88,70,5,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',1.00,NULL),(89,71,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(90,72,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(91,73,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(92,74,1,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',10.00,NULL),(93,75,2,'Mail Delivery',NULL,'311 444 B-1 S-1, Calgary, Alberta 44423, Canada',15.00,NULL),(94,76,5,'Mail Delivery',NULL,'320 520 58th Avn SW, 320, Calgary, Alberta T2V 0H6, Canada',1.00,NULL),(95,77,5,'Mail Delivery',NULL,'320 520 58th Avn SW, 320, Calgary, Alberta T2V 0H6, Canada',1.00,NULL),(107,89,5,'MailDelivery',NULL,'32052058thAvnSW,320,Calgary,AlbertaT2V0H6,Canada',1.00,NULL),(108,90,5,'MailDelivery',NULL,'32052058thAvnSW,320,Calgary,AlbertaT2V0H6,Canada',1.00,NULL),(109,91,5,'MailDelivery',NULL,'32052058thAvnSW,320,Calgary,AlbertaT2V0H6,Canada',1.00,NULL);
/*!40000 ALTER TABLE `order_shipping_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_transaction`
--

DROP TABLE IF EXISTS `order_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_transaction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int DEFAULT NULL,
  `transaction_ref` varchar(100) DEFAULT NULL,
  `transaction_status` enum('Completed','Pending','Processing','Declined','Reversed') DEFAULT NULL,
  `transaction_type` varchar(200) DEFAULT NULL,
  `transaction_amount` double(20,8) DEFAULT NULL,
  `comments` text,
  `trans_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`,`transaction_ref`),
  CONSTRAINT `order_transaction_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_transaction`
--

LOCK TABLES `order_transaction` WRITE;
/*!40000 ALTER TABLE `order_transaction` DISABLE KEYS */;
INSERT INTO `order_transaction` VALUES (1,1,'565863259T4021504','Completed','Paypal',67.90000000,NULL,'2021-03-20 19:59:05'),(2,2,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',100.85000000,'','2021-03-22 05:36:24'),(3,3,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',67.90000000,'','2021-03-22 18:37:41'),(4,4,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',37.95000000,'','2021-03-22 18:50:20'),(5,5,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',37.95000000,'','2021-03-22 18:54:53'),(6,6,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',37.95000000,'','2021-03-23 19:24:48'),(7,7,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',37.95000000,'','2021-03-25 15:53:08'),(8,8,'1XN06061EH5747649','Completed','Paypal',34.95000000,NULL,'2021-03-25 16:17:20'),(9,9,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',67.90000000,'','2021-03-25 16:38:10'),(10,10,'9LB91359P32063144','Completed','Paypal',67.90000000,NULL,'2021-03-25 16:42:25'),(11,11,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',34.95000000,'','2021-03-25 16:49:43'),(12,12,'87F01564UV0925716','Completed','Paypal',34.95000000,NULL,'2021-03-25 16:53:56'),(13,13,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',70.90000000,'','2021-03-25 19:10:04'),(14,14,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',34.95000000,'','2021-03-26 15:00:09'),(15,15,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',67.90000000,'','2021-03-26 15:06:17'),(16,16,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',34.95000000,'','2021-03-26 15:33:03'),(17,17,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',34.95000000,'','2021-03-26 15:41:26'),(18,18,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',103.85000000,'','2021-03-26 19:02:21'),(19,19,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',34.95000000,'','2021-03-26 19:15:16'),(20,20,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',34.95000000,'','2021-03-26 19:18:12'),(21,21,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',34.95000000,'','2021-03-26 19:19:46'),(22,22,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',34.95000000,'','2021-03-26 19:25:41'),(23,23,'6T1273627J435305J','Completed','Paypal',70.90000000,NULL,'2021-03-26 19:28:20'),(24,24,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',70.90000000,'','2021-03-27 04:17:30'),(25,25,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',131.80000000,'','2021-03-27 18:53:52'),(26,26,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',32.95000000,'','2021-03-28 02:16:53'),(27,27,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',32.95000000,'','2021-03-29 14:58:29'),(28,28,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',32.95000000,'','2021-03-30 21:09:08'),(29,29,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',32.95000000,'','2021-03-30 21:11:30'),(30,30,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',32.95000000,'','2021-04-08 18:06:07'),(31,31,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',6.95000000,'','2021-04-08 18:07:47'),(32,32,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',7.65000000,'','2021-04-08 18:28:18'),(33,33,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',7.65000000,'','2021-04-08 18:31:14'),(34,34,'LK1CS9','Completed','Gift Card',7.65000000,'','2021-04-08 18:32:44'),(35,35,'LK1CS9','Completed','Gift Card',17.65000000,'','2021-04-08 19:15:31'),(36,36,'LK1CS9','Completed','Gift Card',1.00000000,'','2021-04-08 19:16:14'),(37,37,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',21.95000000,'','2021-04-08 19:25:16'),(38,38,'admy45vo0lbkmhz0hdw','Pending','Paypal',144.25000000,'','2021-04-08 19:27:56'),(39,38,'LK1CS9','Completed','Gift Card',82.35000000,'','2021-04-08 19:27:56'),(40,39,'admy45vo0lbkmhz0hdw','Pending','Paypal',96.20000000,'','2021-04-08 19:36:29'),(41,39,'LK1CS9','Completed','Gift Card',17.65000000,'','2021-04-08 19:36:29'),(42,40,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',108.85000000,'','2021-04-08 19:38:16'),(43,41,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',31.50000000,'','2021-04-08 19:42:07'),(44,41,'LK1CS9','Completed','Gift Card',82.35000000,'','2021-04-08 19:42:07'),(45,42,'admy45vo0lbkmhz0hdw','Pending','Paypal',91.20000000,'','2021-04-08 19:43:14'),(46,42,'LK1CS9','Completed','Gift Card',17.65000000,'','2021-04-08 19:43:14'),(47,42,'9R109749H92112124','Completed','Paypal',91.20000000,'','2021-04-08 19:53:06'),(48,43,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',212.70000000,'','2021-04-08 20:37:05'),(49,44,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',16.95000000,'','2021-04-09 15:57:01'),(50,45,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',46.25000000,'','2021-04-09 18:09:54'),(51,46,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',51.25000000,'','2021-04-09 18:11:41'),(52,47,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',51.25000000,'','2021-04-09 18:13:46'),(53,48,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',47.95000000,'','2021-04-09 18:17:18'),(54,49,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',54.54000000,'','2021-04-09 18:18:37'),(55,50,'LK1CS9','Completed','Gift Card',39.54000000,'','2021-04-09 19:25:39'),(56,51,'LK1CS9','Completed','Gift Card',54.54000000,'','2021-04-09 20:09:31'),(57,52,'LK1CS9','Completed','Gift Card',39.54000000,'','2021-04-09 20:11:34'),(58,53,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-04-10 17:49:32'),(59,54,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',54.54000000,'','2021-04-16 11:27:32'),(60,55,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',89.08000000,'','2021-04-16 11:35:03'),(61,56,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',49.54000000,'','2021-04-16 11:40:15'),(62,57,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-04-17 18:08:57'),(63,58,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-04-17 18:09:09'),(64,59,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',79.08000000,'','2021-04-17 19:14:04'),(65,60,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-04-17 21:44:53'),(66,61,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-04-22 20:00:59'),(67,62,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-04-22 20:12:09'),(68,63,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-04-22 20:22:07'),(69,64,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-04-23 20:59:19'),(70,65,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',79.08000000,'','2021-04-25 16:51:57'),(71,66,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',79.08000000,'','2021-04-29 15:34:53'),(72,67,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-04-29 23:50:11'),(73,68,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-04-29 23:50:20'),(74,69,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-04-29 23:51:02'),(75,70,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-05-03 12:04:20'),(76,71,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',49.54000000,'','2021-05-03 12:29:23'),(77,72,'admy45vo0lbkmhz0hdw','Pending','Paypal',54.54000000,'','2021-06-09 18:27:14'),(78,72,'4M35714419009294A','Completed','Paypal',54.54000000,'','2021-06-09 18:27:48'),(79,73,'admy45vo0lbkmhz0hdw','Pending','Paypal',54.54000000,'','2021-06-09 18:29:56'),(80,73,'8JB96151T48210307','Completed','Paypal',54.54000000,'','2021-06-09 18:33:21'),(81,74,'admy45vo0lbkmhz0hdw','Pending','Paypal',49.54000000,'','2021-06-09 23:50:20'),(82,74,'6PL10960RR3285202','Completed','Paypal',49.54000000,'','2021-06-09 23:52:07'),(83,75,'admy45vo0lbkmhz0hdw','Pending','Paypal',133.62000000,'','2021-06-09 23:53:46'),(84,75,'25H90032JD3405603','Completed','Paypal',133.62000000,'','2021-06-09 23:54:46'),(85,76,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-06-11 04:28:28'),(86,77,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',39.54000000,'','2021-06-11 04:35:29'),(87,NULL,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',28.39000000,'','2021-06-20 00:15:03'),(88,NULL,'1empbcjsj2ykmhz40gl','Pending','Cash on delivery',28.39000000,'','2021-06-20 00:16:26'),(89,NULL,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:21:24'),(90,NULL,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:22:47'),(91,NULL,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:23:33'),(92,NULL,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:24:01'),(93,NULL,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:25:45'),(94,NULL,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:26:36'),(95,NULL,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:29:00'),(96,NULL,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:30:21'),(97,NULL,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:33:03'),(98,89,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:34:29'),(99,90,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:37:43'),(100,91,'1empbcjsj2ykmhz40gl','Pending','Cashondelivery',28.39000000,'','2021-06-20 00:38:29');
/*!40000 ALTER TABLE `order_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_transaction_assoc`
--

DROP TABLE IF EXISTS `order_transaction_assoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_transaction_assoc` (
  `order_id` int NOT NULL,
  `transaction_id` int NOT NULL,
  UNIQUE KEY `order_id` (`order_id`,`transaction_id`),
  KEY `transaction_id` (`transaction_id`),
  CONSTRAINT `order_transaction_assoc_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_transaction_assoc_ibfk_2` FOREIGN KEY (`transaction_id`) REFERENCES `order_transaction` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_transaction_assoc`
--

LOCK TABLES `order_transaction_assoc` WRITE;
/*!40000 ALTER TABLE `order_transaction_assoc` DISABLE KEYS */;
INSERT INTO `order_transaction_assoc` VALUES (77,86),(89,98),(90,99),(91,100);
/*!40000 ALTER TABLE `order_transaction_assoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `order_ref` varchar(36) DEFAULT NULL,
  `user_data` text,
  `order_status` varchar(100) DEFAULT NULL,
  `referrer` int DEFAULT NULL,
  `clean_referrer` int DEFAULT NULL,
  `dated` timestamp NOT NULL,
  `tax_amount` decimal(10,2) DEFAULT '0.00',
  `sub_shop_code` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_ref` (`order_ref`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `customer_registration` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,1,'6AD5F2F1E186F4A5C61AE0B0F1FF2563','','Payment Pending',NULL,NULL,'2021-03-20 19:57:47',0.00,NULL),(2,1,'6E39D41C9669BC0AA38FB71644AB865A','','Ready for Shipment',NULL,NULL,'2021-03-22 05:36:24',0.00,NULL),(3,1,'3FCBD7C3C194D1035B00BDB84E0DF7CE','','In Workshop Processing',NULL,NULL,'2021-03-22 18:37:41',0.00,NULL),(4,1,'7AB01A6A81794B32743B707B6D6A7D5C','','Payment Pending',NULL,NULL,'2021-03-22 18:50:20',0.00,NULL),(5,1,'E8A47716903FDBF42B649D08DD1FAE07','','Payment Pending',NULL,NULL,'2021-03-22 18:54:53',0.00,NULL),(6,1,'543E0717DB72CCCA5D506B938DE13150','','Payment Pending',NULL,NULL,'2021-03-23 19:24:48',0.00,NULL),(7,1,'C26D9A2CE8C4DD6196E65DF4F7DC82C9','','Payment Pending',NULL,NULL,'2021-03-25 15:53:08',0.00,NULL),(8,1,'67137ED958FFD42EE8AA34C5E61B53F4','','Payment Pending',NULL,NULL,'2021-03-25 16:16:39',0.00,NULL),(9,1,'E79466A0FC6EB2A6ED0FD502418B2276','','Payment Pending',NULL,NULL,'2021-03-25 16:38:10',0.00,NULL),(10,1,'AF78596EEA414551309E8CF9DDA7D5F6','','Payment Pending',NULL,NULL,'2021-03-25 16:41:56',0.00,NULL),(11,1,'033A573BFEF2AA283928FFB1F5013332','','Payment Pending',NULL,NULL,'2021-03-25 16:49:43',0.00,NULL),(12,1,'BBDDF7616C11F7338379C175C77790B7','','Payment Pending',NULL,NULL,'2021-03-25 16:53:29',0.00,NULL),(13,1,'628142BE8E7B817F507D390BA95CAFF8','','Payment Pending',NULL,NULL,'2021-03-25 19:10:04',0.00,NULL),(14,1,'95236A5BB81C8FCAB9402A2544EA8835','','Payment Pending',NULL,NULL,'2021-03-26 15:00:09',0.00,NULL),(15,1,'1443F1204135FE1CE12BC7A178B2AEE5','','Payment Pending',NULL,NULL,'2021-03-26 15:06:17',0.00,NULL),(16,1,'A15071838A4C9F62BC0A822D01E2DF83','','Payment Pending',NULL,NULL,'2021-03-26 15:33:03',0.00,NULL),(17,1,'67834CE4E3A1C652CFAE0EB6CD8F2D4D','These are user data notes','Payment Pending',NULL,NULL,'2021-03-26 15:41:26',0.00,NULL),(18,1,'0E19BFE9713657847F284A97F4796E21','','Payment Pending',NULL,NULL,'2021-03-26 19:02:21',0.00,NULL),(19,1,'A4E735ACD6A76F8BA7515B93769EED5C','','Payment Pending',NULL,NULL,'2021-03-26 19:15:16',0.00,NULL),(20,1,'81BF35850727F45E487C39A0003ED55F','','Payment Pending',NULL,NULL,'2021-03-26 19:18:12',0.00,NULL),(21,1,'C8F1AE7DB4E4CA6EE8B9EEFEC5E1B09B','','Rejected',NULL,NULL,'2021-03-26 19:19:46',0.00,NULL),(22,1,'AF5708CC2402D310C5B1AB86E85435FC','','Payment Pending',NULL,NULL,'2021-03-26 19:25:41',0.00,NULL),(23,1,'6BFDAA2B9395B9E03003210E7AAE2A62','','Payment Pending',NULL,NULL,'2021-03-26 19:27:50',0.00,NULL),(24,2,'B2B93A9B1631A6CF4788B3F6D1846963','','Payment Pending',NULL,NULL,'2021-03-27 04:17:30',0.00,NULL),(25,1,'E9760BC0B7752BAE2E931B3A4FB2E225','','Payment Pending',NULL,NULL,'2021-03-27 18:53:52',0.00,NULL),(26,3,'00270F9FF82F84486830105F9DF4E2D8','','Payment Pending',NULL,NULL,'2021-03-28 02:16:53',0.00,NULL),(27,1,'2C37BA502763AC20CF8973476895B9E8','','Payment Pending',NULL,NULL,'2021-03-29 14:58:29',0.00,NULL),(28,1,'CA0DC9E2E7F60215C7800C39B465D07A','','Payment Pending',NULL,NULL,'2021-03-30 21:09:08',0.00,NULL),(29,1,'48C9C0D27A36A408EBE346FD0699FF31','','Payment Pending',NULL,NULL,'2021-03-30 21:11:30',0.00,NULL),(30,1,'870902615F4D0FCB7F8C15548DE2BA53','','Payment Pending',NULL,NULL,'2021-04-08 18:06:07',0.00,NULL),(31,1,'467DB4FFE31276D48B4D6B4504EB844B','','Payment Pending',NULL,NULL,'2021-04-08 18:07:47',0.00,NULL),(32,1,'C1567ADA4AC6AD441D5A1DB30D35852D','','Payment Pending',NULL,NULL,'2021-04-08 18:28:18',0.00,NULL),(33,1,'C280E394D2FD665D9F9D19A1894B1568','','Payment Pending',NULL,NULL,'2021-04-08 18:31:14',0.00,NULL),(34,1,'B63136DC864BDD6370620F2B4B57CAB2','','Payment Pending',NULL,NULL,'2021-04-08 18:32:44',0.00,NULL),(35,1,'55AFD914A27BE7778AE8E9F9EC4D079A','','Payment Pending',NULL,NULL,'2021-04-08 19:15:31',0.00,NULL),(36,1,'902F6DF4C4B02DFF2735D5D5F5A78362','','Payment Pending',NULL,NULL,'2021-04-08 19:16:14',0.00,NULL),(37,1,'313063FB64065E6C1676DAC05914FAA5','','Payment Pending',NULL,NULL,'2021-04-08 19:25:16',0.00,NULL),(38,1,'A939DBAF8BCACBCB0F170C120221ECEA','','Payment Pending',NULL,NULL,'2021-04-08 19:27:56',0.00,NULL),(39,1,'A18C5B21D5E78E5D3A6DCCA607AF1E3C','','Payment Pending',NULL,NULL,'2021-04-08 19:36:29',0.00,NULL),(40,1,'02071A70D54AD14AB258415DA4D4E0AC','','Payment Pending',NULL,NULL,'2021-04-08 19:38:16',0.00,NULL),(41,1,'A30C86FDF7455408D5DE618CF9EE01B5','','Payment Pending',NULL,NULL,'2021-04-08 19:42:07',0.00,NULL),(42,1,'B6AC641418982BA09A1333678FAE436E','','Payment Pending',NULL,NULL,'2021-04-08 19:43:14',0.00,NULL),(43,1,'B43452B5222D8E50B0F5A367FD26D0DD','','Payment Pending',NULL,NULL,'2021-04-08 20:37:05',0.00,NULL),(44,1,'7C2F8D15F9CB358F2527AC6C292A3253','','Payment Pending',NULL,NULL,'2021-04-09 15:57:01',0.00,NULL),(45,1,'113FF24A3EA84F62757937851CDD8718','','Payment Pending',NULL,NULL,'2021-04-09 18:09:54',0.00,NULL),(46,1,'5F1626724AD872C42BF7C24DB0B8109E','','Payment Pending',NULL,NULL,'2021-04-09 18:11:40',0.00,NULL),(47,1,'A176104725683CD2B5742A1DCFBA687D','','Payment Pending',NULL,NULL,'2021-04-09 18:13:46',3.00,NULL),(48,1,'18B13061736A56BDE68C7769A4323D7B','','Payment Pending',NULL,NULL,'2021-04-09 18:17:18',0.00,NULL),(49,1,'01CEEF75ECD99F9D0CF33196D9F2ADE8','','Payment Pending',NULL,NULL,'2021-04-09 18:18:37',6.59,NULL),(50,1,'D2EA612614940B946D5BFC601799DF5F','','Payment Pending',NULL,NULL,'2021-04-09 19:25:39',6.59,NULL),(51,1,'5E19B0E89D36EC17D618471A090B4FE1','','Payment Pending',NULL,NULL,'2021-04-09 20:09:31',6.59,NULL),(52,1,'D5DEF2786119F688F617C1442A287A31','','Payment Pending',NULL,NULL,'2021-04-09 20:11:34',6.59,NULL),(53,2,'787F14EB2244357153ECA3C32D0E6AFB','','Payment Pending',NULL,NULL,'2021-04-10 17:49:32',6.59,NULL),(54,1,'32834C20D513FCAB8E2FF4F6AF5CFB8B','','Payment Pending',NULL,NULL,'2021-04-16 11:27:32',6.59,NULL),(55,1,'FF556A435F5004D038F190EBC822DAF2','','Payment Pending',NULL,NULL,'2021-04-16 11:35:03',13.18,NULL),(56,1,'05429657CCD057DCC8652F88069A76AA','','Payment Pending',NULL,NULL,'2021-04-16 11:40:15',6.59,NULL),(57,2,'A1D41BED0257A4E7E8BC975F0D657D75','','Payment Pending',NULL,NULL,'2021-04-17 18:08:57',6.59,NULL),(58,2,'FFF6299F53BD55A02B3A67047FE4C15D','','Payment Pending',NULL,NULL,'2021-04-17 18:09:09',6.59,NULL),(59,2,'44FE8B096CC866431EB30FC8EAAFCA5D','','Payment Pending',NULL,NULL,'2021-04-17 19:14:04',13.18,NULL),(60,2,'E7B0444949D226CC2C74501DCFB7889F','','Payment Pending',NULL,NULL,'2021-04-17 21:44:53',6.59,NULL),(61,1,'1qrze9n','','Payment Pending',NULL,NULL,'2021-04-22 20:00:59',6.59,NULL),(62,1,'1.qrzes9','','Payment Pending',NULL,NULL,'2021-04-22 20:12:09',6.59,NULL),(63,1,'1.QRZF8V','','Payment Pending',NULL,NULL,'2021-04-22 20:22:07',6.59,NULL),(64,1,'1.QS1BMV','','Payment Pending',NULL,NULL,'2021-04-23 20:59:19',6.59,NULL),(65,4,'4.QS4PIL','','Payment Pending',NULL,NULL,'2021-04-25 16:51:57',13.18,NULL),(66,1,'1.QSC0M5','','Payment Pending',NULL,NULL,'2021-04-29 15:34:53',13.18,NULL),(67,2,'2.QSCNJN','','Payment Pending',NULL,NULL,'2021-04-29 23:50:11',6.59,NULL),(68,2,'2.QSCNJW','','Payment Pending',NULL,NULL,'2021-04-29 23:50:20',6.59,NULL),(69,2,'2.QSCNL2','','Payment Pending',NULL,NULL,'2021-04-29 23:51:02',6.59,NULL),(70,1,'1.QSJ5J8','','Payment Pending',NULL,NULL,'2021-05-03 12:04:20',6.59,NULL),(71,1,'1.QSJ6OZ','','Payment Pending',NULL,NULL,'2021-05-03 12:29:23',6.59,NULL),(72,1,'1.QUG5XE','','Payment Pending',NULL,NULL,'2021-06-09 18:27:14',6.59,NULL),(73,1,'1.QUG61W','','Payment Pending',NULL,NULL,'2021-06-09 18:29:56',6.59,NULL),(74,1,'1.QUGKVW','','Payment Pending',NULL,NULL,'2021-06-09 23:50:20',6.59,NULL),(75,1,'1.QUGL1M','','Payment Pending',NULL,NULL,'2021-06-09 23:53:46',19.77,NULL),(76,4,'4.QUISFG','','Payment Pending',NULL,NULL,'2021-06-11 04:28:28',6.59,NULL),(77,4,'4.QUISR5','','Payment Pending',NULL,NULL,'2021-06-11 04:35:29',6.59,NULL),(89,4,'4.QUZ5LH','','Payment Pending',NULL,NULL,'2021-06-20 00:34:29',1.39,''),(90,4,'4.QUZ5QV','','Payment Pending',NULL,NULL,'2021-06-20 00:37:43',1.39,''),(91,4,'4.QUZ5S5','','Payment Pending',NULL,NULL,'2021-06-20 00:38:29',1.39,'');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_temp`
--

DROP TABLE IF EXISTS `orders_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_temp` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cart_products` varchar(255) DEFAULT NULL,
  `cart_id` varchar(15) DEFAULT NULL,
  `shop_id` int NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_temp`
--

LOCK TABLES `orders_temp` WRITE;
/*!40000 ALTER TABLE `orders_temp` DISABLE KEYS */;
INSERT INTO `orders_temp` VALUES (19,'a:1:{i:8;i:1;}',NULL,92,5),(30,'a:2:{i:1;i:1;i:7;i:1;}',NULL,92,4);
/*!40000 ALTER TABLE `orders_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_inventory`
--

DROP TABLE IF EXISTS `product_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_inventory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `product_id` int NOT NULL,
  `amount` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_inventory_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `shop_locations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_inventory_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Will Hold the Acumulated In Location Inventory';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_inventory`
--

LOCK TABLES `product_inventory` WRITE;
/*!40000 ALTER TABLE `product_inventory` DISABLE KEYS */;
INSERT INTO `product_inventory` VALUES (1,1,1,11,'2021-04-15 20:35:28'),(2,1,2,110,'2021-03-23 19:23:36'),(3,1,3,110,'2021-03-23 19:23:50'),(4,1,4,110,'2021-03-23 19:24:01'),(5,1,5,110,'2021-03-23 19:24:11'),(6,1,6,110,'2021-03-23 19:24:19'),(7,1,7,110,'2021-03-23 19:24:35'),(8,1,8,220,'2021-03-23 19:21:57'),(9,1,17,10,'2021-04-06 16:32:27'),(10,1,18,0,'2021-04-06 19:17:29');
/*!40000 ALTER TABLE `product_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_inventory_log`
--

DROP TABLE IF EXISTS `product_inventory_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_inventory_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location_id` int NOT NULL,
  `user_id` int NOT NULL,
  `product_id` int NOT NULL,
  `create_date` timestamp NULL DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `comments` varchar(1024) NOT NULL,
  `reference` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `location_id` (`location_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_inventory_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_inventory_log_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `shop_locations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_inventory_log_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_inventory_log`
--

LOCK TABLES `product_inventory_log` WRITE;
/*!40000 ALTER TABLE `product_inventory_log` DISABLE KEYS */;
INSERT INTO `product_inventory_log` VALUES (18,1,1,1,'2021-03-23 18:37:56',100,'',''),(19,1,1,2,'2021-03-23 18:38:20',100,'',''),(20,1,1,3,'2021-03-23 18:38:34',100,'',''),(21,1,1,4,'2021-03-23 18:39:22',100,'',''),(22,1,1,5,'2021-03-23 18:39:32',100,'',''),(23,1,1,6,'2021-03-23 18:39:48',100,'',''),(24,1,1,7,'2021-03-23 18:40:02',100,'',''),(25,1,1,8,'2021-03-23 18:40:15',100,'',''),(26,1,1,8,'2021-03-23 19:16:09',100,'',''),(27,1,1,8,'2021-03-23 19:19:08',10,'',''),(28,1,1,8,'2021-03-23 19:21:57',10,'',''),(29,1,1,1,'2021-03-23 19:23:27',10,'',''),(30,1,1,2,'2021-03-23 19:23:36',10,'',''),(31,1,1,3,'2021-03-23 19:23:50',10,'',''),(32,1,1,4,'2021-03-23 19:24:01',10,'',''),(33,1,1,5,'2021-03-23 19:24:11',10,'',''),(34,1,1,6,'2021-03-23 19:24:19',10,'',''),(35,1,1,7,'2021-03-23 19:24:35',10,'',''),(40,1,1,1,'2021-03-30 13:54:06',1,'',''),(41,1,1,1,'2021-03-30 13:54:36',-111,'',''),(42,1,1,1,'2021-03-30 13:55:17',50,'',''),(43,1,1,17,'2021-04-06 16:32:27',10,'',''),(44,1,1,18,'2021-04-06 16:32:53',17,'',''),(45,1,1,18,'2021-04-06 19:17:29',-17,'',''),(46,1,1,1,'2021-04-15 19:57:09',10,'',''),(47,1,1,1,'2021-04-15 20:02:06',-10,'',''),(48,1,1,1,'2021-04-15 20:35:12',-49,'',''),(49,1,1,1,'2021-04-15 20:35:28',10,'','');
/*!40000 ALTER TABLE `product_inventory_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_filters`
--

DROP TABLE IF EXISTS `shop_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_filters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filter_name` varchar(255) NOT NULL,
  `filter_link` varchar(255) NOT NULL,
  `display_index` int NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_filters`
--

LOCK TABLES `shop_filters` WRITE;
/*!40000 ALTER TABLE `shop_filters` DISABLE KEYS */;
INSERT INTO `shop_filters` VALUES (1,'Featured','4',1,'2021-03-20 15:52:06',NULL),(2,'New Arrivals','6',2,'2021-03-20 15:52:06',NULL),(3,'Best Sellers','4',3,'2021-03-20 15:52:06',NULL),(4,'Sports','10',4,'2021-03-20 15:52:06',NULL),(5,'Casual','12',5,'2021-03-20 15:52:06',NULL),(6,'Under $20','16',6,'2021-03-20 15:52:06',NULL),(7,'Half Rim','17',7,'2021-03-20 15:52:06',NULL);
/*!40000 ALTER TABLE `shop_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_filters_def`
--

DROP TABLE IF EXISTS `shop_filters_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_filters_def` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_filters_def`
--

LOCK TABLES `shop_filters_def` WRITE;
/*!40000 ALTER TABLE `shop_filters_def` DISABLE KEYS */;
INSERT INTO `shop_filters_def` VALUES (1,'Frames','%7B%22catCode%22%253A%22frames%22%7D','2021-03-20 15:52:04','2021-03-25 13:10:07'),(2,'Sunglasses','%7B%22catCode%22%3A%22sunglasses%22%7D','2021-03-20 15:52:04',NULL),(3,'Reading Glasses','%7B%22catCode%22%3A%22reading_glass%22%7D','2021-03-20 15:52:04',NULL),(4,'Featured','%7B%22featured%22%3A%22yes%22%7D','2021-03-20 15:52:04',NULL),(5,'Best Sellers','%7B%22featured%22%3A%22yes%22%7D','2021-03-20 15:52:04',NULL),(6,'Latest','%7B%22latest%22%3A%2215+days%22%7D','2021-03-20 15:52:04',NULL),(7,'Men','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22demograghics%22%3A%22gender_men%22%7D%7D%7D','2021-03-20 15:52:04','2021-03-25 13:14:44'),(8,'Women','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22demograghics%22%3A%22gender_women%22%7D%7D%7D','2021-03-20 15:52:04',NULL),(9,'Ray Ban','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22brand%22%3A%22brand_ray_ban%22%7D%7D%7D','2021-03-20 15:52:05',NULL),(10,'Safety Glasses','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22mood%22%3A%22mood_sports%22%7D%7D%7D','2021-03-20 15:52:05',NULL),(11,'Formal','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22mood%22%3A%22mood_formal%22%7D%7D%7D','2021-03-20 15:52:05',NULL),(12,'Casual','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22mood%22%3A%22mood_casual%22%7D%7D%7D','2021-03-20 15:52:05',NULL),(13,'Rectangle','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22frame_shape%22%3A%22frame_shape_rectangle%22%7D%7D%7D','2021-03-20 15:52:05',NULL),(14,'Cat Eye','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22frame_shape%22%3A%22frame_shape_cat_eye%22%7D%7D%7D','2021-03-20 15:52:05',NULL),(15,'Aviator','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22frame_shape%22%3A%22frame_shape_aviator%22%7D%7D%7D','2021-03-20 15:52:05',NULL),(16,'Under $20','%7B%22price_max%22%3A%2220%22%7D','2021-03-20 15:52:05','2021-04-01 13:08:39'),(17,'Half Rim','%7B%22FilterBy%22%3A%7B%22style%22%3A%7B%22frame_type%22%3A%22frame_type_half_rim%22%7D%7D%7D','2021-03-20 15:52:05',NULL);
/*!40000 ALTER TABLE `shop_filters_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_locations`
--

DROP TABLE IF EXISTS `shop_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_locations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(512) NOT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `address` varchar(512) DEFAULT NULL,
  `city` varchar(512) DEFAULT NULL,
  `state` varchar(512) DEFAULT NULL,
  `country` varchar(512) DEFAULT NULL,
  `zipcode` varchar(512) DEFAULT NULL,
  `status` enum('active','inactive','unregistered','suspended') NOT NULL,
  `lat` double(20,8) DEFAULT NULL,
  `lng` double(20,8) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_locations`
--

LOCK TABLES `shop_locations` WRITE;
/*!40000 ALTER TABLE `shop_locations` DISABLE KEYS */;
INSERT INTO `shop_locations` VALUES (1,'066d3543e3','islamabad','4033697919','muftimuid@gmail.com','313 quarry green SE','CALGARY','AB','CA',NULL,'active',33.69069579,73.03249831,'2021-03-28 03:00:46','2021-03-23 14:54:02');
/*!40000 ALTER TABLE `shop_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_product_images`
--

DROP TABLE IF EXISTS `shop_product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_product_images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image` text NOT NULL,
  `product_id` int NOT NULL,
  `image_type` enum('360','product') NOT NULL DEFAULT 'product',
  `shop_id` int NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `vtry` tinyint(1) NOT NULL COMMENT '0= No, 1=Yes',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `shop_product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_product_images`
--

LOCK TABLES `shop_product_images` WRITE;
/*!40000 ALTER TABLE `shop_product_images` DISABLE KEYS */;
INSERT INTO `shop_product_images` VALUES (1,'16162564071306.png',1,'product',92,0,0),(2,'16162564071161.png',1,'product',92,0,0),(4,'16162571866484.png',2,'product',92,0,0),(5,'16162571867781.png',2,'product',92,0,0),(6,'16162571863858.png',2,'product',92,0,0),(7,'16162571865497.png',2,'product',92,0,0),(8,'16162572179327.png',3,'product',92,0,0),(9,'16162572174338.png',3,'product',92,0,0),(10,'16162572175134.png',3,'product',92,0,0),(11,'161625721710.png',3,'product',92,0,0),(12,'16162572609919.png',4,'product',92,0,0),(13,'16162572607490.png',4,'product',92,0,0),(14,'16162572604473.png',4,'product',92,0,0),(15,'16162572608137.png',4,'product',92,0,0),(16,'16162572609256.png',4,'product',92,0,0),(17,'16162572915271.png',5,'product',92,0,0),(18,'16162572912235.png',5,'product',92,0,0),(19,'16162572911777.png',5,'product',92,0,0),(20,'16162573274129.png',6,'product',92,0,0),(21,'16162573271592.png',6,'product',92,0,0),(22,'1616257327560.png',6,'product',92,0,0),(23,'16162573284568.png',6,'product',92,0,0),(24,'1616257439535.png',7,'product',92,0,0),(25,'16162574392330.png',7,'product',92,0,0),(26,'16162574401528.png',7,'product',92,0,0),(27,'16162576863664.png',8,'product',92,0,0),(28,'16162576866753.png',8,'product',92,0,0),(36,'16168744331541.png',1,'360',92,0,0),(37,'16168744346971.png',1,'360',92,0,0),(40,'1617387086956.png',17,'product',92,0,0),(43,'16173871544490.png',17,'360',92,0,0),(46,'1617387086956.png',18,'product',92,0,0),(47,'16173871544490.png',18,'360',92,0,0),(48,'16186879124329.png',7,'product',92,0,0),(49,'16196422891978.png',19,'product',92,0,0),(50,'16196426362193.png',20,'product',92,0,0),(51,'16196427377908.png',21,'product',92,0,0);
/*!40000 ALTER TABLE `shop_product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_products`
--

DROP TABLE IF EXISTS `shop_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_cat_code` varchar(100) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `title` varchar(512) NOT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `location` int NOT NULL DEFAULT '1' COMMENT 'Inventory Location ID',
  `abbr` varchar(10) DEFAULT NULL COMMENT 'Abbrivation',
  `base_price` double(12,2) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `visibility` tinyint(1) DEFAULT NULL,
  `discount` double(12,2) DEFAULT NULL,
  `product_desc` text,
  `is_feature` enum('no','yes') NOT NULL DEFAULT 'no' COMMENT 'no,yes',
  `cost` decimal(10,2) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `back_order` int NOT NULL DEFAULT '0',
  `secondry_attr` text,
  `modal_number` varchar(255) DEFAULT NULL,
  `product_img` varchar(255) DEFAULT NULL,
  `sort_index` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_products`
--

LOCK TABLES `shop_products` WRITE;
/*!40000 ALTER TABLE `shop_products` DISABLE KEYS */;
INSERT INTO `shop_products` VALUES (1,'frames','pc-7823112','Oval Glasses 7823112','oval-glasses-7823112',1,'en',32.95,NULL,'2021-03-20 16:06:46','2021-03-27 19:47:09',NULL,NULL,'Style and comfort come together in these wide oval glasses. The lightweight frame features a hand-polished acetate front with a playful tortoiseshell pattern on the brow. The slender temple arms have brushed metal detailing at the hinge and feature acetate temple tips for added comfort. This style is available in charcoal and clear.','yes',32.95,'1',1,'Feature: High Rx\nBridge: 20 mm','oval-222',NULL,0,1),(2,'frames','pc-7823122','Oval Glasses 7823122','oval-glasses-7823122',1,'en',32.95,NULL,'2021-03-20 16:19:45','2021-04-10 17:01:01',NULL,NULL,'Style and comfort come together in these wide oval glasses. The lightweight frame features a hand-polished acetate front with a playful tortoiseshell pattern on the brow. The slender temple arms have brushed metal detailing at the hinge and feature acetate temple tips for added comfort. This style is available in charcoal and clear.','yes',32.95,'1',1,'Tags: Acetate Glasses\nFeature: High Rx\nFrame Weight: 19 grams','oval-222',NULL,0,1),(3,'frames','pc-7823123','Oval Glasses 7823123','oval-glasses-7823123',1,'en',32.95,1,'2021-03-20 16:20:16',NULL,NULL,NULL,'Style and comfort come together in these wide oval glasses. The lightweight frame features a hand-polished acetate front with a playful tortoiseshell pattern on the brow. The slender temple arms have brushed metal detailing at the hinge and feature acetate temple tips for added comfort. This style is available in charcoal and clear.','yes',32.95,'1',1,'Tags: Acetate Glasses\nFeature: High Rx\nFrame Weight: 19 grams','oval-222',NULL,1,1),(4,'frames','pc-7823124','Oval Glasses 7823124','oval-glasses-7823124',1,'en',32.95,1,'2021-03-20 16:20:59',NULL,NULL,NULL,'Style and comfort come together in these wide oval glasses. The lightweight frame features a hand-polished acetate front with a playful tortoiseshell pattern on the brow. The slender temple arms have brushed metal detailing at the hinge and feature acetate temple tips for added comfort. This style is available in charcoal and clear.','yes',32.95,'1',1,'Tags: Acetate Glasses\nFeature: High Rx\nFrame Weight: 19 grams','oval-222',NULL,1,1),(5,'frames','pc-7823125','Oval Glasses 7823125','oval-glasses-7823125',1,'en',32.95,1,'2021-03-20 16:21:30',NULL,NULL,NULL,'Style and comfort come together in these wide oval glasses. The lightweight frame features a hand-polished acetate front with a playful tortoiseshell pattern on the brow. The slender temple arms have brushed metal detailing at the hinge and feature acetate temple tips for added comfort. This style is available in charcoal and clear.','yes',32.95,'1',1,'Tags: Acetate Glasses\nFeature: High Rx\nFrame Weight: 19 grams','oval-222',NULL,1,1),(6,'frames','pc-7823126','Oval Glasses 7823126','oval-glasses-7823126',1,'en',32.95,1,'2021-03-20 16:22:07',NULL,NULL,NULL,'Style and comfort come together in these wide oval glasses. The lightweight frame features a hand-polished acetate front with a playful tortoiseshell pattern on the brow. The slender temple arms have brushed metal detailing at the hinge and feature acetate temple tips for added comfort. This style is available in charcoal and clear.','yes',32.95,'1',1,'Tags: Acetate Glasses\nFeature: High Rx\nFrame Weight: 19 grams','oval-222',NULL,1,1),(7,'sunglasses','pc-7823127','Shades Glasses 7823127','shades-glasses-7823127',1,'en',32.95,NULL,'2021-03-20 16:23:59','2021-04-17 19:31:52',NULL,NULL,'Style and comfort come together in these wide oval glasses. The lightweight frame features a hand-polished acetate front with a playful tortoiseshell pattern on the brow. The slender temple arms have brushed metal detailing at the hinge and feature acetate temple tips for added comfort. This style is available in charcoal and clear.','yes',32.95,'1',1,'Tags: Acetate Glasses\nFeature: High Rx\nFrame Weight: 19 grams','shades-222',NULL,0,1),(8,'sunglasses','pc-7823128','Shades Glasses 7823128','shades-glasses-7823128',1,'en',32.95,NULL,'2021-03-20 16:28:05','2021-04-28 20:56:27',NULL,NULL,'Style and comfort come together in these wide oval glasses. The lightweight frame features a hand-polished acetate front with a playful tortoiseshell pattern on the brow. The slender temple arms have brushed metal detailing at the hinge and feature acetate temple tips for added comfort. This style is available in charcoal and clear.','no',32.95,'1',1,'Tags: Acetate Glasses\nFeature: High Rx\nFrame Weight: 19 grams','shades-222',NULL,0,1),(17,'reading_glass','pc-445111','Eye Glasses 445111','eye-glasses-445111',1,'en',6.95,NULL,'2021-03-27 20:02:31','2021-04-02 18:13:39',NULL,NULL,'asjkdn asjkcaks ckjbnaskdc ksdjfas vjkasbfjkdnf','yes',6.95,'1',1,NULL,'m-4455',NULL,0,1),(18,'reading_glass','pc-445111-copy18','Eye Glasses 445111 copy18','eye-glasses-445111-copy18',1,'en',6.95,NULL,'2021-03-27 20:02:31','2021-04-02 18:13:39',NULL,NULL,'asjkdn asjkcaks ckjbnaskdc ksdjfas vjkasbfjkdnf','yes',6.95,'1',1,NULL,'m-4455',NULL,0,1),(19,'sunglasses','pc-7822','Oval Glasses 7822','oval-glasses-7822',1,'en',NULL,NULL,'2021-04-28 20:38:08','2021-04-28 20:39:17',NULL,NULL,'askjnd sjkdnkas dkasnkdsand','yes',NULL,'1',1,NULL,'shades-222',NULL,0,1),(20,'sunglasses','pc-1231','Oval Glasses 1231','oval-glasses-1231',1,'en',NULL,1,'2021-04-28 20:43:55',NULL,NULL,NULL,'as,dnas dkanskdnasknd','yes',NULL,'1',-1,'','oval-123',NULL,1,1),(21,'sunglasses','pc-44','Sunglasses 44','sunglasses-44',1,'en',NULL,1,'2021-04-28 20:45:36',NULL,NULL,NULL,NULL,'no',NULL,'',1,'','s-4',NULL,1,1);
/*!40000 ALTER TABLE `shop_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_settings`
--

DROP TABLE IF EXISTS `shop_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key_shop` varchar(255) DEFAULT NULL,
  `value_shop` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_settings`
--

LOCK TABLES `shop_settings` WRITE;
/*!40000 ALTER TABLE `shop_settings` DISABLE KEYS */;
INSERT INTO `shop_settings` VALUES (1,'pick_from_store','Active'),(2,'cash_on_delivery','Active'),(3,'paypal_setting','Inactive'),(4,'merchant_email',''),(5,'360','Active'),(6,'delivery_charges','100'),(7,'vtryon','Active'),(8,'main_theme','Formal'),(9,'sub_theme','1'),(10,'color_scheme','Light'),(11,'facebook_link','https://www.facebook.com'),(12,'twitter_link','https://www.twitter.com'),(13,'instagram_link','https://www.instagram.com'),(14,'whatsapp_link',''),(15,'youtube_link','https://youtube.com'),(16,'tax','20'),(17,'shop_description','djqwhbd asjbqasb cjabsdjcsd jkqasfk s dfgdfgdfg'),(18,'contact_email','ainak@gmail.com');
/*!40000 ALTER TABLE `shop_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_slides_banners`
--

DROP TABLE IF EXISTS `shop_slides_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_slides_banners` (
  `id` int NOT NULL AUTO_INCREMENT,
  `t1` varchar(255) DEFAULT NULL,
  `t2` varchar(255) DEFAULT NULL,
  `t3` varchar(255) DEFAULT NULL,
  `t3_link` varchar(500) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `display_index` int DEFAULT NULL,
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_slides_banners`
--

LOCK TABLES `shop_slides_banners` WRITE;
/*!40000 ALTER TABLE `shop_slides_banners` DISABLE KEYS */;
INSERT INTO `shop_slides_banners` VALUES (1,'Frames','Collection','Show More','1','slides/slide_1.png','slide',1,'2021-03-20 15:52:05'),(2,'Protective Eyewear','Safety Glasses','Show More','10','slides/slide_2.png','slide',2,'2021-03-20 15:52:05'),(3,'Extended Fit','Glasses','Show More','11','slides/slide_3.png','slide',3,'2021-03-20 15:52:05'),(4,'Gaming','Eye Protectors','Show More','12','slides/slide_4.png','slide',4,'2021-03-20 15:52:05'),(5,'Sunglasses','From totally trendy to classically cool','Show More','2','banners/banner1.png','banner',1,'2021-03-20 15:52:05'),(6,'Latest','Glasses','Show More','6','banners/banner2.png','banner',2,'2021-03-20 15:52:05'),(7,'Men','Glasses','Show More','7','banners/banner3.png','banner',3,'2021-03-20 15:52:05'),(8,'Women','Glasses','Show More','8','banners/banner4.png','banner',4,'2021-03-20 15:52:05'),(9,'Shades','Ray Ban Icons','Discover More','2','banners/banner5.png','banner',5,'2021-03-20 15:52:05'),(10,'Timeless Look','The Aviator','Discover More','15','banners/banner6.png','banner',6,'2021-03-20 15:52:06'),(11,'Universal Bridge','Fit Glasses','Show More','15','banners/banner7.png','banner',7,'2021-03-20 15:52:06'),(12,'Special collection already available.','','Show More','4','banners/banner8.png','banner',8,'2021-03-20 15:52:06'),(13,'Clearance','','Under $20','16','banners/banner9.png','banner',9,'2021-03-20 15:52:06');
/*!40000 ALTER TABLE `shop_slides_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_glasscolors`
--

DROP TABLE IF EXISTS `tag_glasscolors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_glasscolors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tag_glasscolors_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_glasscolors`
--

LOCK TABLES `tag_glasscolors` WRITE;
/*!40000 ALTER TABLE `tag_glasscolors` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_glasscolors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_glasses_type`
--

DROP TABLE IF EXISTS `tag_glasses_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_glasses_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `frame-color` varchar(255) DEFAULT NULL,
  `Frame-Material` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tag_glasses_type_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_glasses_type`
--

LOCK TABLES `tag_glasses_type` WRITE;
/*!40000 ALTER TABLE `tag_glasses_type` DISABLE KEYS */;
INSERT INTO `tag_glasses_type` VALUES (3,7,'Black','Plastic','Rectangle'),(4,8,'Brown','Nylon','Wrap');
/*!40000 ALTER TABLE `tag_glasses_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_lens_details`
--

DROP TABLE IF EXISTS `tag_lens_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_lens_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `lens_index_1d56_standard_lens` varchar(255) DEFAULT NULL,
  `lens_index_1d59_polycarbonate` varchar(255) DEFAULT NULL,
  `lens_index_1d61_thin` varchar(255) DEFAULT NULL,
  `lens_index_1d67_ultra_thin` varchar(255) DEFAULT NULL,
  `lens_type` varchar(255) DEFAULT NULL,
  `lens_type_clear_lenses` varchar(255) DEFAULT NULL,
  `lens_type_photochromatic_(dark_in_sun)` varchar(255) DEFAULT NULL,
  `lens_type_sunglasses_(always_dark)` varchar(255) DEFAULT NULL,
  `photochromatic_color_photochromatic_brown` varchar(255) DEFAULT NULL,
  `photochromatic_color_photochromatic_grey` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tag_lens_details_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_lens_details`
--

LOCK TABLES `tag_lens_details` WRITE;
/*!40000 ALTER TABLE `tag_lens_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_lens_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_lens_power`
--

DROP TABLE IF EXISTS `tag_lens_power`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_lens_power` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `lens_add` varchar(255) DEFAULT NULL,
  `lens_cyl` varchar(255) DEFAULT NULL,
  `lens_prism` varchar(255) DEFAULT NULL,
  `lens_sph` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tag_lens_power_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_lens_power`
--

LOCK TABLES `tag_lens_power` WRITE;
/*!40000 ALTER TABLE `tag_lens_power` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_lens_power` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_lenscolor`
--

DROP TABLE IF EXISTS `tag_lenscolor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_lenscolor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `clear` varchar(255) DEFAULT NULL,
  `dulat` varchar(255) DEFAULT NULL,
  `gradt` varchar(255) DEFAULT NULL,
  `lensecolor2` varchar(255) DEFAULT NULL,
  `mirror` varchar(255) DEFAULT NULL,
  `photac` varchar(255) DEFAULT NULL,
  `polmirror` varchar(255) DEFAULT NULL,
  `polzed` varchar(255) DEFAULT NULL,
  `Solid` varchar(255) DEFAULT NULL,
  `solid_tint_shades_dark` varchar(255) DEFAULT NULL,
  `solid_tint_shades_light` varchar(255) DEFAULT NULL,
  `solid_tint_shades_medium` varchar(255) DEFAULT NULL,
  `sunglasses` varchar(255) DEFAULT NULL,
  `tint_shade_2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tag_lenscolor_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_lenscolor`
--

LOCK TABLES `tag_lenscolor` WRITE;
/*!40000 ALTER TABLE `tag_lenscolor` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_lenscolor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_material`
--

DROP TABLE IF EXISTS `tag_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_material` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `front_material` varchar(255) DEFAULT NULL,
  `side_material` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tag_material_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_material`
--

LOCK TABLES `tag_material` WRITE;
/*!40000 ALTER TABLE `tag_material` DISABLE KEYS */;
INSERT INTO `tag_material` VALUES (3,3,'front_material_plastic','side_matrial_metal'),(4,4,'front_material_plastic','side_matrial_metal'),(5,5,'front_material_plastic','side_matrial_metal'),(6,6,'front_material_plastic','side_matrial_metal'),(13,1,'front_material_metal','side_matrial_metal'),(14,2,'front_material_plastic','side_matrial_metal');
/*!40000 ALTER TABLE `tag_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_prescription`
--

DROP TABLE IF EXISTS `tag_prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_prescription` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `add` varchar(255) DEFAULT NULL,
  `axis` varchar(255) DEFAULT NULL,
  `cyl` varchar(255) DEFAULT NULL,
  `left_pd` varchar(255) DEFAULT NULL,
  `left_prism` varchar(255) DEFAULT NULL,
  `left_prism_direction` varchar(255) DEFAULT NULL,
  `pd` varchar(255) DEFAULT NULL,
  `prism` varchar(255) DEFAULT NULL,
  `right_pd` varchar(255) DEFAULT NULL,
  `right_prism` varchar(255) DEFAULT NULL,
  `right_prism_direction` varchar(255) DEFAULT NULL,
  `sph` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tag_prescription_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_prescription`
--

LOCK TABLES `tag_prescription` WRITE;
/*!40000 ALTER TABLE `tag_prescription` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_prescription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_properties`
--

DROP TABLE IF EXISTS `tag_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_properties` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `number` double(12,4) DEFAULT NULL,
  `style` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tag_properties_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_properties`
--

LOCK TABLES `tag_properties` WRITE;
/*!40000 ALTER TABLE `tag_properties` DISABLE KEYS */;
INSERT INTO `tag_properties` VALUES (16,17,'type_boy',0.0800,'style_circle'),(17,18,'type_boy',0.0800,'style_circle');
/*!40000 ALTER TABLE `tag_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_size`
--

DROP TABLE IF EXISTS `tag_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_size` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `frame-width` varchar(255) DEFAULT NULL,
  `frame_pd` varchar(255) DEFAULT NULL,
  `lens_height` varchar(255) DEFAULT NULL,
  `lens_width` varchar(255) DEFAULT NULL,
  `max_pd` varchar(255) DEFAULT NULL,
  `min_pd` varchar(255) DEFAULT NULL,
  `SML-Size` varchar(255) DEFAULT NULL,
  `temple_length` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tag_size_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_size`
--

LOCK TABLES `tag_size` WRITE;
/*!40000 ALTER TABLE `tag_size` DISABLE KEYS */;
INSERT INTO `tag_size` VALUES (3,3,'frame_width_115','frame_pd_70','Lens_Height_22','lw_47','max_pd_63','min_pd_60','small','temple_length_130'),(4,4,'frame_width_115','frame_pd_70','Lens_Height_22','lw_47','max_pd_63','min_pd_60','small','temple_length_130'),(5,5,'frame_width_115','frame_pd_70','Lens_Height_22','lw_47','max_pd_63','min_pd_60','small','temple_length_130'),(6,6,'frame_width_115','frame_pd_70','Lens_Height_22','lw_47','max_pd_63','min_pd_60','small','temple_length_130'),(13,1,'frame_width_113','frame_pd_61','Lens_Height_22','lw_47','max_pd_62','min_pd_60','medium','temple_length_130'),(14,2,'frame_width_115','frame_pd_70','Lens_Height_22','lw_47','max_pd_63','min_pd_60','small','temple_length_130');
/*!40000 ALTER TABLE `tag_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_style`
--

DROP TABLE IF EXISTS `tag_style`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_style` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `demograghics` varchar(255) DEFAULT NULL,
  `frame_shape` varchar(255) DEFAULT NULL,
  `frame_type` varchar(255) DEFAULT NULL,
  `mood` varchar(255) DEFAULT NULL,
  `prescription_type` varchar(255) DEFAULT NULL,
  `presc_type_bimfocal` varchar(255) DEFAULT NULL,
  `presc_type_progressive` varchar(255) DEFAULT NULL,
  `presc_type_reading` varchar(255) DEFAULT NULL,
  `presc_type_single_vision` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tag_style_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `shop_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_style`
--

LOCK TABLES `tag_style` WRITE;
/*!40000 ALTER TABLE `tag_style` DISABLE KEYS */;
INSERT INTO `tag_style` VALUES (3,3,'brand_ray_ban','gender_men|gender_women','frame_shape_square','frame_type_full_rim','mood_formal|mood_casual','presc_type_bimfocal|presc_type_progressive',NULL,NULL,NULL,NULL),(4,4,'brand_gucci','gender_women|gender_girl','frame_shape_square','frame_type_full_rim','mood_formal|mood_casual','presc_type_bimfocal|presc_type_progressive',NULL,NULL,NULL,NULL),(5,5,'brand_gucci','gender_men|gender_women|gender_boy|gender_girl','frame_shape_square','frame_type_full_rim','mood_formal|mood_casual','presc_type_bimfocal|presc_type_progressive',NULL,NULL,NULL,NULL),(6,6,'brand_gucci','gender_men|gender_boy','frame_shape_square','frame_type_full_rim','mood_formal|mood_casual','presc_type_bimfocal|presc_type_progressive',NULL,NULL,NULL,NULL),(13,1,'brand_ray_ban','gender_men|gender_women','frame_shape_oval','frame_type_full_rim','mood_casual','presc_type_bimfocal|presc_type_progressive',NULL,NULL,NULL,NULL),(14,2,'brand_ray_ban','gender_women','frame_shape_square','frame_type_full_rim','mood_formal|mood_casual','presc_type_bimfocal|presc_type_progressive',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tag_style` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_address`
--

DROP TABLE IF EXISTS `user_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_address` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `unit_no` varchar(100) DEFAULT NULL,
  `street_addr` varchar(512) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `county` varchar(100) DEFAULT NULL,
  `postal_code` varchar(25) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_address_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Manage User Shipping Address';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_address`
--

LOCK TABLES `user_address` WRITE;
/*!40000 ALTER TABLE `user_address` DISABLE KEYS */;
INSERT INTO `user_address` VALUES (1,3,'331','444 B-1 S-1','Calgary','Alberta','CA','44423','1242351453');
/*!40000 ALTER TABLE `user_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_data`
--

DROP TABLE IF EXISTS `user_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `template_code` varchar(255) NOT NULL,
  `value` json NOT NULL,
  `label` varchar(255) NOT NULL,
  `creation_Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `user_data_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_data`
--

LOCK TABLES `user_data` WRITE;
/*!40000 ALTER TABLE `user_data` DISABLE KEYS */;
INSERT INTO `user_data` VALUES (1,1,'pres_data','{\"pd\": \"49\", \"od_add\": \"+0.50\", \"od_cyl\": \"-4.50\", \"od_sph\": \"-11.25\", \"os_add\": \"+3.00\", \"os_cyl\": \"-1.00\", \"os_sph\": \"-8.25\", \"od_axis\": \"178\", \"os_axis\": \"163\", \"pd_left\": \"\", \"pd_right\": \"\", \"left_prism\": \"\", \"right_prism\": \"\", \"left_prism_direction\": \"\", \"right_prism_direction\": \"\"}','Asad','2021-03-20 21:02:04',NULL),(2,1,'contact_lens_data','{\"notes\": \"These are noyes\", \"dia_ctc_lens\": \"\", \"power_ctc_lens\": \"\", \"base_curve_ctc_lens\": \"\"}','Asad','2021-03-22 14:27:59',NULL),(3,2,'pres_data','{\"pd\": \"68\", \"od_add\": \"+1.00\", \"od_cyl\": \"+0.00\", \"od_sph\": \"-9.50\", \"os_add\": \"+2.00\", \"os_cyl\": \"-4.25\", \"os_sph\": \"-10.00\", \"od_axis\": \"164\", \"os_axis\": \"167\", \"pd_left\": \"\", \"pd_right\": \"\", \"left_prism\": \"\", \"right_prism\": \"\", \"left_prism_direction\": \"\", \"right_prism_direction\": \"\"}','Muid','2021-03-23 05:09:37',NULL),(4,3,'pres_data','{\"pd\": \"65\", \"od_add\": \"+0.75\", \"od_cyl\": \"-1.00\", \"od_sph\": \"-0.75\", \"os_add\": \"+0.75\", \"os_cyl\": \"-1.00\", \"os_sph\": \"-0.75\", \"od_axis\": \"145\", \"os_axis\": \"140\", \"pd_left\": \"\", \"pd_right\": \"\", \"left_prism\": \"1.25\", \"right_prism\": \"1.25\", \"left_prism_direction\": \"OUT\", \"right_prism_direction\": \"OUT\"}','Nasir','2021-03-28 02:48:12',NULL),(5,3,'contact_lens_data','{\"notes\": \"This is a test\", \"dia_ctc_lens\": \"\", \"power_ctc_lens\": \"\", \"base_curve_ctc_lens\": \"\"}','Nasir','2021-03-28 02:50:33',NULL),(6,4,'pres_data','{\"pd\": \"47\", \"od_add\": \"+0.00\", \"od_cyl\": \"-4.75\", \"od_sph\": \"-12.00\", \"os_add\": \"+2.50\", \"os_cyl\": \"-2.75\", \"os_sph\": \"-11.50\", \"od_axis\": \"180\", \"os_axis\": \"168\", \"pd_left\": \"\", \"pd_right\": \"\", \"left_prism\": \"\", \"right_prism\": \"\", \"left_prism_direction\": \"\", \"right_prism_direction\": \"\"}','Arif','2021-03-28 15:54:06',NULL),(7,2,'pres_data','{\"pd\": \"69\", \"od_add\": \"+3.00\", \"od_cyl\": \"-1.25\", \"od_sph\": \"-8.25\", \"os_add\": \"+2.50\", \"os_cyl\": \"-2.75\", \"os_sph\": \"-7.50\", \"od_axis\": \"164\", \"os_axis\": \"164\", \"pd_left\": \"\", \"pd_right\": \"\", \"left_prism\": \"\", \"right_prism\": \"\", \"left_prism_direction\": \"\", \"right_prism_direction\": \"\"}','MUID2','2021-03-28 16:05:46',NULL),(8,2,'pres_data','{\"pd\": \"\", \"od_add\": \"+3.25\", \"od_cyl\": \"-0.25\", \"od_sph\": \"-7.50\", \"os_add\": \"+3.50\", \"os_cyl\": \"-0.25\", \"os_sph\": \"-7.50\", \"od_axis\": \"160\", \"os_axis\": \"160\", \"pd_left\": \"37.5\", \"pd_right\": \"38.5\", \"left_prism\": \"\", \"right_prism\": \"\", \"left_prism_direction\": \"\", \"right_prism_direction\": \"\"}','MMMM','2021-03-28 16:06:37',NULL),(9,2,'pres_data','{\"pd\": \"72\", \"od_add\": \"+0.75\", \"od_cyl\": \"+0.00\", \"od_sph\": \"+0.00\", \"os_add\": \"+1.25\", \"os_cyl\": \"-4.00\", \"os_sph\": \"-11.00\", \"od_axis\": \"178\", \"os_axis\": \"175\", \"pd_left\": \"\", \"pd_right\": \"\", \"left_prism\": \"\", \"right_prism\": \"\", \"left_prism_direction\": \"\", \"right_prism_direction\": \"\"}','AAAA','2021-03-28 17:34:54',NULL),(11,1,'contact_lens_data','{\"notes\": \"qwefdfbv dfgdfg\", \"dia_ctc_lens\": \"\", \"power_ctc_lens\": \"\", \"base_curve_ctc_lens\": \"\"}','Asad1','2021-04-09 18:35:09',NULL),(12,1,'contact_lens_data','{\"attachment\": [\"userdata/1/16179954169095.JPG\"]}','File','2021-04-09 19:10:16',NULL);
/*!40000 ALTER TABLE `user_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_prescription`
--

DROP TABLE IF EXISTS `user_prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_prescription` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lenses_id` varchar(200) DEFAULT NULL,
  `lenses_label` varchar(200) DEFAULT NULL,
  `rx_image_file` varchar(200) DEFAULT NULL,
  `coating_id` varchar(200) DEFAULT NULL,
  `coating_label` varchar(200) DEFAULT NULL,
  `prescription_id` varchar(200) DEFAULT NULL,
  `pres_price` varchar(200) DEFAULT NULL,
  `pres_prices_array` varchar(1000) DEFAULT NULL,
  `presc_opt` varchar(200) DEFAULT NULL,
  `od_sph_ttl` varchar(200) DEFAULT NULL,
  `od_sph` varchar(200) DEFAULT NULL,
  `od_cyl_ttl` varchar(200) DEFAULT NULL,
  `od_cyl` varchar(200) DEFAULT NULL,
  `od_axis` varchar(200) DEFAULT NULL,
  `od_add_ttl` varchar(200) DEFAULT NULL,
  `od_add` varchar(200) DEFAULT NULL,
  `os_sph_ttl` varchar(200) DEFAULT NULL,
  `os_sph` varchar(200) DEFAULT NULL,
  `os_cyl_ttl` varchar(200) DEFAULT NULL,
  `os_cyl` varchar(200) DEFAULT NULL,
  `os_axis` varchar(200) DEFAULT NULL,
  `os_add_ttl` varchar(200) DEFAULT NULL,
  `os_add` varchar(200) DEFAULT NULL,
  `pd_single` varchar(200) DEFAULT NULL,
  `pd_right` varchar(200) DEFAULT NULL,
  `pd_left` varchar(200) DEFAULT NULL,
  `pdtype` varchar(200) DEFAULT NULL,
  `prism` varchar(15) DEFAULT NULL,
  `prism_right` varchar(50) DEFAULT NULL,
  `prism_left` varchar(50) DEFAULT NULL,
  `prism_right_direct` varchar(50) DEFAULT NULL,
  `prism_left_direct` varchar(50) DEFAULT NULL,
  `patient_name` varchar(200) DEFAULT NULL,
  `patient_id` int DEFAULT NULL,
  `hid_rx_type` varchar(200) DEFAULT NULL,
  `hid_rx_type_label` varchar(200) DEFAULT NULL,
  `hid_lens_type` varchar(200) DEFAULT NULL,
  `hid_lens_type_label` varchar(200) DEFAULT NULL,
  `lens_option` varchar(200) DEFAULT NULL,
  `lens_option_label` varchar(200) NOT NULL,
  `lens_coating` varchar(100) DEFAULT NULL,
  `lens_coating_label` varchar(100) DEFAULT NULL,
  `tint_opt_id` varchar(200) DEFAULT NULL,
  `tint_opt` varchar(200) DEFAULT NULL,
  `tint_solid_variant` varchar(200) DEFAULT NULL,
  `tint_color` varchar(200) DEFAULT NULL,
  `order_id` int NOT NULL,
  `sendlater` varchar(10) NOT NULL,
  `full_array` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_prescription`
--

LOCK TABLES `user_prescription` WRITE;
/*!40000 ALTER TABLE `user_prescription` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_prescription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_registration`
--

DROP TABLE IF EXISTS `user_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_registration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL COMMENT 'User Email Address',
  `password` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `dob` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'User Date Of Birth',
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Registration Time Stamp',
  `last_logedin` timestamp NULL DEFAULT NULL COMMENT 'Last Login Activity',
  `phone` varchar(20) DEFAULT NULL,
  `zipcode` varchar(20) DEFAULT NULL,
  `is_deactivated` varchar(20) NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_registration`
--

LOCK TABLES `user_registration` WRITE;
/*!40000 ALTER TABLE `user_registration` DISABLE KEYS */;
INSERT INTO `user_registration` VALUES (1,'asad.uh15@gmail.com','2662bb3eb87214a228cb8cf67b4ff255','Asad','Ullah','2021-03-20 15:52:04','2021-03-20 15:52:04',NULL,'',NULL,'no'),(2,'ngulzari@gmail.com','81dc9bdb52d04dc20036dbd8313ed055','Muhammad','Gulzari','2021-03-28 02:55:20','2021-03-28 02:55:20',NULL,'4108028567',NULL,'no'),(3,'labuser@lh.com','81dc9bdb52d04dc20036dbd8313ed055','Lab','User','2021-03-29 15:09:11','2021-03-29 15:09:11',NULL,'1242351453',NULL,'no'),(4,'muid@email.com','81dc9bdb52d04dc20036dbd8313ed055','Muid','Mufti','2021-04-17 18:34:45','2021-04-17 18:34:45',NULL,'1234567',NULL,'no');
/*!40000 ALTER TABLE `user_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `user_id` int NOT NULL,
  `role` varchar(100) NOT NULL COMMENT 'Defined in Code. Sales Person,Manager, Admin etc',
  UNIQUE KEY `user_id` (`user_id`,`role`),
  CONSTRAINT `user_role_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,'shop_admin'),(1,'shop_manager'),(2,'shop_manager'),(3,'workshop_manager'),(4,'workshop_manager');
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-08  4:06:53
